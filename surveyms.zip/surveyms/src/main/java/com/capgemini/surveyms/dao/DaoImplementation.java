package com.capgemini.surveyms.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.controller.RespondentController;
import com.capgemini.surveyms.controller.SurveyorController;
import com.capgemini.surveyms.exception.SurveyNotFoundException;
import com.capgemini.surveyms.factory.Factory;

/**
 * This is an implementation of Dao interface and its methods
 * 
 * @author Peter
 *
 */
public class DaoImplementation implements Dao {

	/**
	 * This adminLogin method is used to Login into the administration with his
	 * credentials. It will decide for the operations which it has to perform when
	 * it matches with the credentials after this.
	 * 
	 * * @return true when details matched
	 * 
	 * @return false when details not matched
	 * 
	 * @param username
	 * 
	 * @param password
	 * 
	 */
	@Override
	public boolean adminLogin(String adminName, String adminPassword) {
		return adminName.contentEquals("admin") && adminPassword.contentEquals("admin");

	}

	/**
	 * This method surveyorView is used to view if the Surveyor login credential
	 * list is empty of not.
	 * 
	 * @return true if surveyorView is empty
	 * @return false if surveyorView is not empty
	 */
	@Override
	public boolean adminViewSurveyor() {
		return SurveyorController.surveyorLoginList.isEmpty();

	}

	/**
	 * This surveyAdd method is used to Add new surveys to the list
	 * 
	 * @param surveyBean
	 * @return false or true.
	 * 
	 */
	@Override
	public boolean surveyAdd(SurveyBean surveyBean) {
		return (SurveyorController.surveyList.isEmpty());

	}

	/**
	 * This method respondentAdd is used to view if the Respondent login credential
	 * list is empty of not.
	 * 
	 * @return true if added
	 * @return false if not added
	 */
	public boolean addNewRespondent(String newRespondentName, String newRespondentPassword) {
		RespondentBean respondentBean = Factory.getRespondentBeanInstance();

		respondentBean.setUserName(newRespondentName);
		respondentBean.setPassword(newRespondentPassword);

		ArrayList<RespondentBean> list = new ArrayList<RespondentBean>();
		list.add(respondentBean);
		return RespondentController.loginOfRespondent.addAll(list);

	}

	/**
	 * This login method is used to Login into the surveyor with his credentials. It
	 * will decide for the operations which it has to perform when it matches with
	 * the credentials after this.
	 * 
	 * @param login
	 *            surveyorUsername and surveyorPassword
	 * @return true when details added
	 * 
	 * @return false when details not added
	 * 
	 */

	@Override
	public boolean surveyorLogin(String surveyorUsername, String surveyorPassword) {
		return (surveyorUsername.contentEquals("surveyor") && surveyorPassword.equals("surveyor"));
	}

	public boolean addSurvey(String surveyName) {

		int count = 0;
		for (SurveyBean checkSurveyPresent : SurveyorController.surveyList) {
			if (checkSurveyPresent.getName().contentEquals(surveyName)) {
				count++;
			}
		}
		return (count != 0);

	}

	public boolean zz(SurveyBean surveyBean, String surveyName, String editSurvey, String description,
			LocalDate startDate, LocalDate endDate, String questionOne, String option0One, String option0Two,
			String option0Three, String option0Four, String questionTwo, String optionOne, String optionTwo,
			String optionThree, String optionFour, String questionThree, String questionFour, String questionFive,
			String distribute) {

		surveyBean.setName(editSurvey.replaceAll(editSurvey, surveyName));

		// surveyBean.setName(surveyName);
		surveyBean.setDescription(description);
		surveyBean.setStartDate(startDate);
		surveyBean.setEndDate(endDate);
		surveyBean.setDefaultQuestionOne(questionOne);
		surveyBean.setQuestionOneOptionOne(optionOne);
		surveyBean.setQuestionOneOptionTwo(optionTwo);
		surveyBean.setQuestionOneOptionThree(optionThree);
		surveyBean.setQuestionOneOptionFour(optionFour);

		surveyBean.setDefaultQuestionTwo(questionTwo);
		surveyBean.setQuestionTwoOptionOne(option0One);
		surveyBean.setQuestionTwoOptionTwo(option0Two);
		surveyBean.setQuestionTwoOptionThree(option0Three);
		surveyBean.setQuestionTwoOptionFour(option0Four);

		surveyBean.setDefaultQuestionThree(questionThree);
		surveyBean.setDefaultQuestionFour(questionFour);
		surveyBean.setDefaultQuestionFive(questionFive);
		surveyBean.setdistributedTo(distribute);
		surveyBean.setResponses("0");
		return SurveyorController.surveyList.add(surveyBean);

	}

	public boolean creatingSurvey(String surveyName, String description, LocalDate startdate, LocalDate enddate,
			String question0One, String option0One, String option0Two, String option0Three, String option0Four,
			String questionTwo, String optionOne, String optionTwo, String optionThree, String optionFour,
			String questionThree, String questionFour, String questionFive, String distribute) {
		SurveyBean surveyBean = Factory.getSurveyBeanInstance();

		surveyBean.setName(surveyName);
		surveyBean.setDescription(description);
		surveyBean.setStartDate(startdate);
		surveyBean.setEndDate(enddate);
		surveyBean.setDefaultQuestionOne(question0One);
		surveyBean.setQuestionOneOptionOne(option0One);
		surveyBean.setQuestionOneOptionTwo(option0Two);
		surveyBean.setQuestionOneOptionThree(option0Three);
		surveyBean.setQuestionOneOptionFour(option0Four);
		surveyBean.setDefaultQuestionTwo(questionTwo);
		surveyBean.setQuestionTwoOptionOne(optionOne);
		surveyBean.setQuestionTwoOptionTwo(optionTwo);
		surveyBean.setQuestionTwoOptionThree(optionThree);
		surveyBean.setQuestionTwoOptionFour(optionFour);
		surveyBean.setDefaultQuestionThree(questionThree);
		surveyBean.setDefaultQuestionFour(questionFour);
		surveyBean.setDefaultQuestionFive(questionFive);
		surveyBean.setdistributedTo(distribute);
		surveyBean.setResponses("0");
		return SurveyorController.surveyList.add(surveyBean);
	}

	/**
	 * This surveyView method is used to view surveys present in the list
	 * 
	 * @return false or true.
	 * 
	 */
	@Override
	public boolean surveyView() {
		return SurveyorController.surveyList.isEmpty();

	}

	@Override
	public boolean checkZero(SurveyBean surveysList) {
		return surveysList.getResponses().contentEquals("0");
	}

	int count = 0;

	/**
	 * This deleteSurvey method is used to delete surveys present in the list
	 * 
	 * @param survey
	 * @return false or true.
	 * 
	 */
	@Override
	public boolean deleteSurvey(String survey) throws SurveyNotFoundException {
		for (SurveyBean surveyBean : SurveyorController.surveyList) {
			if (surveyBean.getName().equals(survey)) {
				count++;
				SurveyorController.surveyList.remove(surveyBean);
				return true;
			}
		}
		if (count == 0)
			throw new SurveyNotFoundException();
		return false;

	}

	/**
	 * This surveyUpdate method is used to Add new surveys to the list
	 * 
	 * @param surveyOne
	 * @return false or true.
	 * 
	 */
	@Override
	public boolean surveyUpdate(String surveyOne, SurveyBean surveyList) {
		if (surveyList.getName().equals(surveyOne)) {
			return true;
		} else
			return false;

	}

	public boolean contentIsNull(SurveyBean surveyList) {
		return surveyList.getdistributedTo().contentEquals("");
	}

	/**
	 * This surveyResponseView method is used to view responses for surveys given
	 * 
	 * @return false is list is not empty.
	 * @return true if list is empty
	 * 
	 */
	@Override
	public boolean surveyResponseView() {
		return RespondentController.surveyResponseList.isEmpty();

	}

	/**
	 * This method respondentView is used to view if the Respondent login credential
	 * list is empty of not.
	 * 
	 * @return true if loginOfRespondent is empty
	 * @return false if loginOfRespondent is not empty
	 */
	@Override
	public boolean viewRespondentPresent() {
		return RespondentController.loginOfRespondent.isEmpty();

	}

	/**
	 * respondentFound is used to check whether respondent is present
	 * 
	 * @param userName
	 * 
	 * @return true when details added
	 * 
	 * @return false when details not added
	 */
	@Override
	public boolean checkRespondentPresent(String userName) {

		for (RespondentBean respondentbean : RespondentController.loginOfRespondent) {
			if (respondentbean.getUserName().contentEquals(userName)) {

				for (SurveyBean surveyorBean : SurveyorController.surveyList) {

					if (surveyorBean.getdistributedTo().contentEquals(userName)) {
						return true;
					}
				}
			}
		}
		return false;

	}

	@Override
	public boolean checkResponseStatus(String userName) {
		for (RespondentBean respondentBeanThree : RespondentController.loginOfRespondent) {
			if (respondentBeanThree.getUserName().contentEquals(userName)) {
				for (SurveyBean surveyLists : SurveyorController.surveyList) {
					if (surveyLists.getdistributedTo().contentEquals(userName)) {
						if (surveyLists.getResponses().contentEquals("1")) {

							return true;
						}
					}
				}
			}
		}
		return false;
	}

	@Override
	public void setResponse(SurveyBean surveyLists, String setValue) {
		surveyLists.setResponses(setValue.replace("0", setValue));

	}

	@Override
	public List<String> addResponses(String surveyName, String oneDetails, String twoDetails, String threeDetails,
			String fourDetails, String fiveDetails) {
		List<String> list = new ArrayList<String>();
		list.add(surveyName);
		list.add(oneDetails);
		list.add(twoDetails);
		list.add(threeDetails);
		list.add(fourDetails);
		list.add(fiveDetails);
		RespondentController.surveyResponseList.addAll(list);
		return list;
	}

	@Override
	public boolean response(SurveyBean surveyLists) {
		return surveyLists.getResponses().contentEquals("0");
	}
}
