package com.capgemini.surveyms.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyms.bean.SurveyorBean;
import com.capgemini.surveyms.factory.Factory;

/**
 * 
 * The SurveyorLoginRepository class contains the Login credentials of the
 * Surveyor.
 *
 */
public class SurveyorLoginRepository {

	public static List<SurveyorBean> surveyorLoginList = new ArrayList<SurveyorBean>();

	public List<SurveyorBean> surveyorTable() {

		SurveyorBean surveyorBean = Factory.getSurveyorBeanInstance();
		surveyorBean.setUserName("surveyor");
		surveyorBean.setPassword("surveyor");
		surveyorLoginList.add(surveyorBean);
		return surveyorLoginList;
	}
}