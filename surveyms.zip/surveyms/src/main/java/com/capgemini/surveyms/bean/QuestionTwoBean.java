package com.capgemini.surveyms.bean;

import java.io.Serializable;

/**
 * 
 * This is a Bean Class which contains The Second Question Information which is
 * displayed for the respondent while Responding the survey Which contains
 * Private variables.
 * 
 * The Getter and Setter methods are to Get and Set the Variables.
 */
public class QuestionTwoBean implements Serializable {
	public QuestionTwoBean() {
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String answerTwo;

	/**
	 * This Method getAnswerTwo() Is Used Get the answer Two
	 * 
	 * 
	 * @return answerTwo
	 */
	public String getAnswerTwo() {
		return answerTwo;
	}

	/**
	 * This Method setAnswerTwo() Is Used Set the answer two
	 * 
	 * 
	 * @param answerTwo
	 */
	public void setAnswerTwo(String answerTwo) {
		this.answerTwo = answerTwo;
	}

	@Override
	public String toString() {
		return "QuestionTwoBean [answerTwo=" + answerTwo + "]";
	}

}
