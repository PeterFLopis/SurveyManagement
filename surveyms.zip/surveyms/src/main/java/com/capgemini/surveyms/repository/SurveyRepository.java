package com.capgemini.surveyms.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.factory.Factory;

/**
 * 
 * The SurveyRepository class contains the Dummy Survey details.
 *
 */
public class SurveyRepository {
	public static final org.apache.log4j.Logger logger = Logger.getLogger(SurveyRepository.class);
	public static final List<SurveyBean> surveyLogList = new ArrayList<SurveyBean>();

	public List<SurveyBean> surveyTable() {

		ArrayList<SurveyBean> list = new ArrayList<SurveyBean>();

		SurveyBean surveyBeanOne = Factory.getSurveyBeanInstance();
		surveyBeanOne.setName("cricket");
		surveyBeanOne.setDescription("survey");
		surveyBeanOne.setStartDate(LocalDate.of(2020, 04, 10));
		surveyBeanOne.setEndDate(LocalDate.of(2020, 04, 16));
		surveyBeanOne.setDefaultQuestionOne("Who is Your favourite Cricketer? ");
		surveyBeanOne.setQuestionOneOptionOne("Virat");
		surveyBeanOne.setQuestionOneOptionTwo("Dhoni");
		surveyBeanOne.setQuestionOneOptionThree("Sachin");
		surveyBeanOne.setQuestionOneOptionFour("Rohit");
		surveyBeanOne.setDefaultQuestionTwo("Whcih is your favourite IPL team? ");
		surveyBeanOne.setQuestionTwoOptionOne("RCB");
		surveyBeanOne.setQuestionTwoOptionTwo("CSK");
		surveyBeanOne.setQuestionTwoOptionThree("MI");
		surveyBeanOne.setQuestionTwoOptionFour("KXiP");
		surveyBeanOne.setDefaultQuestionThree("Which is your Home ground? n");
		surveyBeanOne.setDefaultQuestionFour("What is your opinion on IPL?");
		surveyBeanOne.setDefaultQuestionFive("Describe Indian Cricket. ");
	surveyBeanOne.setdistributedTo("");
		surveyBeanOne.setResponses("0");
		

		list.add(surveyBeanOne);

		SurveyBean surveyBeanTwo = Factory.getSurveyBeanInstance();
		surveyBeanTwo.setName("Education");
		surveyBeanTwo.setDescription("A Survey on Education System of India");
		surveyBeanTwo.setStartDate(LocalDate.of(2020, 06, 05));
		surveyBeanTwo.setEndDate(LocalDate.of(2020, 06, 06));
		surveyBeanTwo.setDefaultQuestionOne("What is your Highest qualification");
		surveyBeanTwo.setQuestionOneOptionOne("Bachelors");
		surveyBeanTwo.setQuestionOneOptionTwo("Masters");
		surveyBeanTwo.setQuestionOneOptionThree("SSLC");
		surveyBeanTwo.setQuestionOneOptionFour("Diploma");
		surveyBeanTwo.setDefaultQuestionTwo("Which education system do you prefer");
		surveyBeanTwo.setQuestionTwoOptionOne("Online");
		surveyBeanTwo.setQuestionTwoOptionTwo("Only Practicle");
		surveyBeanTwo.setQuestionTwoOptionThree("Only Theory");
		surveyBeanTwo.setQuestionTwoOptionFour("Both Option two and three");
		surveyBeanTwo.setDefaultQuestionThree("Do you want your next generation to face exams");
		surveyBeanTwo.setDefaultQuestionFour("Your opinion of Our current Education system");
		surveyBeanTwo.setDefaultQuestionFive("What changes you want in our current education system");
		surveyBeanTwo.setdistributedTo("peter");
		surveyBeanTwo.setResponses("0");
		list.add(surveyBeanTwo);

		SurveyBean surveyBeanThree = Factory.getSurveyBeanInstance();
		surveyBeanThree.setName("Covid");
		surveyBeanThree.setDescription("A Survey on Corona virus in India");
		surveyBeanThree.setStartDate(LocalDate.of(2020, 06, 06));
		surveyBeanThree.setEndDate(LocalDate.of(2020, 06, 11));
		surveyBeanThree.setDefaultQuestionOne("Which way is the best according to you to fight Corona");
		surveyBeanThree.setQuestionOneOptionOne("Only Lockdowns");
		surveyBeanThree.setQuestionOneOptionTwo("By applying FaceMasks and Social Distancing");
		surveyBeanThree.setQuestionOneOptionThree("Getting out of home only when required");
		surveyBeanThree.setQuestionOneOptionFour("All of the above");

		surveyBeanThree.setDefaultQuestionTwo("Who among this is mostly affected by COVID");
		surveyBeanThree.setQuestionTwoOptionOne("Daily wage workers.");
		surveyBeanThree.setQuestionTwoOptionTwo("Unemployeed Graduates");
		surveyBeanThree.setQuestionTwoOptionThree("Students");
		surveyBeanThree.setQuestionTwoOptionFour("All of the above");

		surveyBeanThree.setDefaultQuestionThree("How can we completly overcome Covid-19");
		surveyBeanThree.setDefaultQuestionFour("Should government spend more on feeding the affected or not");
		surveyBeanThree.setDefaultQuestionFive("What changes you want from the government for facing Covid");
		surveyBeanThree.setdistributedTo("respondent");
		surveyBeanThree.setResponses("0");
		
		list.add(surveyBeanThree);

		
		SurveyBean surveyBeanFour = Factory.getSurveyBeanInstance();
		surveyBeanFour.setName("Tourism");
		surveyBeanFour.setDescription("Survey on Karnataka Tourism.");
		surveyBeanFour.setStartDate(LocalDate.of(2020, 07, 10));
		surveyBeanFour.setEndDate(LocalDate.of(2020, 07, 16));
		surveyBeanFour.setDefaultQuestionOne("Which place did you like the most after visiting Karnataka ");
		surveyBeanFour.setQuestionOneOptionOne("Shimoga");
		surveyBeanFour.setQuestionOneOptionTwo("Chikmagaluru");
		surveyBeanFour.setQuestionOneOptionThree("Karwar");
		surveyBeanFour.setQuestionOneOptionFour("Mysore");
		surveyBeanFour.setDefaultQuestionTwo("What did you enjoy the most over there ");
		surveyBeanFour.setQuestionTwoOptionOne("Food");
		surveyBeanFour.setQuestionTwoOptionTwo("Climate");
		surveyBeanFour.setQuestionTwoOptionThree("Histrorical Monuments");
		surveyBeanFour.setQuestionTwoOptionFour("Greenary");
		surveyBeanFour.setDefaultQuestionThree("How did you come to know about this place");
		surveyBeanFour.setDefaultQuestionFour("Would you like to recommend this place to your friends");
		surveyBeanFour.setDefaultQuestionFive("Describe the place and the hospitality given to you at the place ");
		surveyBeanFour.setdistributedTo("user");
		surveyBeanFour.setResponses("0");
		
		list.add(surveyBeanFour);
		

		SurveyBean surveyBeanFive = Factory.getSurveyBeanInstance();
		surveyBeanFive.setName("ipl");
		surveyBeanFive.setDescription("Survey of ipl");
		surveyBeanFive.setStartDate(LocalDate.of(2020, 07, 10));
		surveyBeanFive.setEndDate(LocalDate.of(2020, 07, 16));
		surveyBeanFive.setDefaultQuestionOne("Who is Your favourite Cricketer ");
		surveyBeanFive.setQuestionOneOptionOne("Virat");
		surveyBeanFive.setQuestionOneOptionTwo("Dhoni");
		surveyBeanFive.setQuestionOneOptionThree("Sachin");
		surveyBeanFive.setQuestionOneOptionFour("Rohit");
		surveyBeanFive.setDefaultQuestionTwo("Whcih is your favourite IPL team");
		surveyBeanFive.setQuestionTwoOptionOne("RCB");
		surveyBeanFive.setQuestionTwoOptionTwo("CSK");
		surveyBeanFive.setQuestionTwoOptionThree("MI");
		surveyBeanFive.setQuestionTwoOptionFour("KXiP");
		surveyBeanFive.setDefaultQuestionThree("Which is your Home ground");
		surveyBeanFive.setDefaultQuestionFour("What is your opinion on IPL");
		surveyBeanFive.setDefaultQuestionFive("Describe Indian Cricket. ");
		surveyBeanFive.setdistributedTo("");
		surveyBeanFive.setResponses("0");
		
		list.add(surveyBeanFive);
		


		surveyLogList.addAll(list);
		return surveyLogList;

	}

}
