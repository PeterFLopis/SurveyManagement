package com.capgemini.surveyms.exception;

public class ConcurrentModificationException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String message = "Survey  not Found";

	public ConcurrentModificationException() {

	}

	public ConcurrentModificationException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}