package com.capgemini.surveyms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.controller.RespondentController;
import com.capgemini.surveyms.dao.Dao;
import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.validations.InputValidations;

/**
 * This methods in this class acts like a bridge between controller and
 * validation
 * 
 */
public class ServiceImplementation implements Service {
	InputValidations inputValidations = Factory.getInputValidationInstance();
	Dao dao = Factory.getDAOInstance();

	//
	@Override
	public boolean adminLogin(String adminName, String adminPassword) {
		boolean loginCredentials = dao.adminLogin(adminName, adminPassword);
		return (loginCredentials);
	}

	@Override
	public boolean adminViewSurveyor() {
		return dao.adminViewSurveyor();

	}

	@Override
	public boolean addNewRespondent(String newRespondentName, String newRespondentPassword) {
		int count = 0;
		for (RespondentBean respondentControl : RespondentController.loginOfRespondent) {
			if (respondentControl.getUserName().equals(newRespondentName)) {
				count++;
			}
		}
		if (count == 0) {
			dao.addNewRespondent(newRespondentName, newRespondentPassword);
			return true;
		} else {
			return false;
		}
	}

	/* surveyor */
	@Override
	public boolean surveyorLogin(String surveyorUserName, String surveyorPassword) {
		boolean login = dao.surveyorLogin(surveyorUserName, surveyorPassword);
		return (login);
	}

	@Override
	public boolean checkSurvey(String surveyName) {
		return dao.addSurvey(surveyName);
	}

	@Override
	public boolean createSurvey(String surveyName, String description, LocalDate startdate, LocalDate enddate,
			String question0One, String option0One, String option0Two, String option0Three, String option0Four,
			String questionTwo, String optionOne, String optionTwo, String optionThree, String optionFour,
			String questionThree, String questionFour, String questionFive, String distribute) {
		return dao.creatingSurvey(surveyName, description, startdate, enddate, question0One, option0One, option0Two,
				option0Three, option0Four, questionTwo, optionOne, optionTwo, optionThree, optionFour, questionThree,
				questionFour, questionFive, distribute);
	}

	@Override
	public boolean viewSurvey() {
		return dao.surveyView();

	}

	@Override
	public boolean deleteSurvey(String survey) {
		return dao.deleteSurvey(survey);
	}

	@Override
	public boolean editsurvey(String surveybean, SurveyBean s) {
		return dao.surveyUpdate(surveybean, s);
	}


	@Override
	public boolean checkZero(SurveyBean surveysList) {
		return dao.checkZero(surveysList);
	}

	@Override
	public boolean contentIsNull(SurveyBean surveyList) {
		return dao.contentIsNull(surveyList);
	}

	public boolean response(SurveyBean surveyLists) {
		return dao.response(surveyLists);
	}

	@Override
	public boolean viewResponseSurveyOne() {
		return dao.surveyResponseView();
	}

	//
	@Override
	public boolean viewRespondentPresent() {
		return dao.viewRespondentPresent();
	}

	@Override
	public boolean checkRespondentPresent(String userName) {
		return dao.checkRespondentPresent(userName);
	}

	@Override
	public boolean checkResponseStatus(String userName) {
		return dao.checkResponseStatus(userName);
	}

	@Override
	public void setResponse(SurveyBean surveyLists, String responseStatus) {
		dao.setResponse(surveyLists, responseStatus);
	}

	@Override
	public List<String> addResponses(String surveyName, String oneDetails, String twoDetails, String threeDetails,
			String fourDetails, String fiveDetails) {

		return dao.addResponses(surveyName, oneDetails, twoDetails, threeDetails, fourDetails, fiveDetails);
	}

	//
	@Override
	public boolean adminChoice(String option) {

		while (!inputValidations.choiceOneToSix(option)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean passwordVerification(String password) {
		while (!inputValidations.passwordValidation(password)) {
			return false;
		}
		return true;

	}

	@Override
	public boolean choiceOneToFour(String choice) {
		while (!inputValidations.choiceOneToFour(choice)) {

			return false;
		}
		return true;

	}

	@Override
	public boolean choiceOneToTwo(String choice) {
		while (!inputValidations.choiceOneToTwo(choice)) {

			return false;
		}
		return true;

	}

	@Override
	public boolean surveyLineVerify(String name) {
		while (!inputValidations.lineInput(name)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean dateVerify(String name) {
		while (!inputValidations.date(name)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validatePassword(String password) {
		while (!inputValidations.passwordValidation(password)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean choiceOneToSix(String choice) {

		while (!inputValidations.choiceOneToSix(choice)) {

			return false;
		}
		return true;
	}

	@Override
	public boolean choiceOneToThree(String choice) {
		while (!inputValidations.choiceOneToThree(choice)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean respondentService(String choice) {
		while (!inputValidations.choiceOneToSix(choice)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean nameValidations(String userName) {
		while (!inputValidations.nameValidation(userName)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean answerValidationTwoFiftyCharacters(String answer) {
		while (!inputValidations.answerValidationForTwoFiftyCharacters(answer)) {
			return false;
		}
		return true;
	}

	
	@Override
	public boolean answerValidationFourThousandCharacters(String answer) {
		while (!inputValidations.answerValidationFourThousandCharacters(answer)) {
			return false;
		}
		return true;
	}

}
