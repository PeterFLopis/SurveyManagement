package com.capgemini.surveyms.controller;

/**
 * @author Peter
 * 
 *         In the Controller class then user can login  as administrator, where he can add surveyors and respondents. The
 *         surveyor can be able to Add,delete and view the surveys.He can also
 *         update the survey if it is not distributed. Respondent will be able
 *         to respond a survey which is assigned to him and to view his
 *         responses.
 */
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.service.Service;
import com.capgemini.surveyms.bean.RespondentBean;

public class Controller {

	static final Logger logger = Logger.getLogger(Controller.class);
	static final Scanner scanner = new Scanner(System.in);
	static Service controllerService = Factory.getServiceInstance();

	public static void main(String[] args) {

		logger.info(RespondentController.LINE + "\nWelcome To Survey Management System.\n" + RespondentController.LINE
				+ "\nPlease select your choice :\n(ex: Press '1' to Login as Admin)\n");

		do {

			logger.info("1. Admin\n2. Surveyor\n3. Respondent\n4. Exit\n" + RespondentController.LINE + "\n");
			String choice = scanner.nextLine();

			while (!controllerService.choiceOneToFour(choice)) {

				logger.info("please enter valid choice between 1 to 4");
				choice = scanner.nextLine();
			}

			int choiceInteger = Integer.parseInt(choice);

			switch (choiceInteger) {

			case 1:
				AdminController adminControl = Factory.getAdminControllerInstance();
				adminControl.adminLogin();
				break;

			case 2:
				SurveyorController surveyorControl = Factory.getSurveyorControllerInstance();
				surveyorControl.surveyorLoginProcess();
				break;

			case 3:
				RespondentController respondentControl = Factory.getRespondentControllerInstance();
				respondentControl.respondentLogin(new RespondentBean());
				break;

			case 4:
				logger.info("\nThank You !!! Please visit again.\nExit the Screen.");
				System.exit(0);
				break;
			default:
				logger.info("Select valid option\n");
				scanner.close();
			}
		} while (true);
	}
}
