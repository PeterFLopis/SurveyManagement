package com.capgemini.surveyms.bean;

import java.io.Serializable;

/**
 * 
 * This is a Bean Class which contains Respondent Login Information Which
 * contains Private variables.
 * 
 * The Getter and Setter methods are to Get and Set the Variables.
 */
public class RespondentBean implements Serializable {
	public RespondentBean() {
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;

	/**
	 * 
	 * This Method Is Used To get Respondents UserName
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * 
	 * This Method Is Used To Set Respondents UserName
	 * 
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 
	 * This Method Is Used To get Respondents password
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * 
	 * This Method Is Used To Set Respondents password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "RespondentBean [userName=" + userName + ", password=" + password + "]";
	}

}
