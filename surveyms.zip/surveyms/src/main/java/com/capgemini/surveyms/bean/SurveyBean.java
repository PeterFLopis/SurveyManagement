package com.capgemini.surveyms.bean;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * 
 * This is a Bean Class which contains Survey Question Information Which
 * contains Private variables.
 * 
 * The Getter and Setter methods are to Get and Set the Variables.
 */

public class SurveyBean implements Serializable {
	public SurveyBean() {
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String description;
	private LocalDate startDate;
	private LocalDate endDate;

	private String defaultQuestionOne;
	private String questionOneOptionOne;
	private String questionOneOptionTwo;
	private String questionOneOptionThree;
	private String questionOneOptionFour;

	private String defaultQuestionTwo;
	private String questionTwoOptionOne;
	private String questionTwoOptionTwo;
	private String questionTwoOptionThree;
	private String questionTwoOptionFour;

	private String defaultQuestionThree;
	private String defaultQuestionFour;
	private String defaultQuestionFive;

	/**
	 * This method is to get the name of the survey
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * This Method setName() Is Used set the survey name
	 * 
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * This method is to get the description of the survey
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * This Method setDescription() Is Used set the survey description
	 * 
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * This method is to get the StartDate of the survey
	 * 
	 * @return getStartDate
	 */

	public LocalDate getStartDate() {
		return startDate;

	}

	/**
	 * This Method setStartDate() Is Used set the survey start date
	 * 
	 * 
	 * @param startDate
	 */
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	/**
	 * This method is to get the EndDate of the survey
	 * 
	 * @return getEndDate
	 */
	public LocalDate getEndDate() {
		return endDate;
	}

	/**
	 * This Method setEndDate() Is Used set the survey end date
	 * 
	 * 
	 * @param endDate
	 */
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	/**
	 * This method is to get the option one of first question of the survey
	 * 
	 * @return questionTwoOptionOne
	 */
	public String getQuestionTwoOptionOne() {
		return questionTwoOptionOne;
	}

	/**
	 * This method is to set the option one of first question of the survey
	 * 
	 * @param questionTwoOptionOne
	 */
	public void setQuestionTwoOptionOne(String questionTwoOptionOne) {
		this.questionTwoOptionOne = questionTwoOptionOne;
	}

	/**
	 * This method is to get the option two of second question of the survey
	 * 
	 * @return questionTwoOptionTwo
	 */
	public String getQuestionTwoOptionTwo() {
		return questionTwoOptionTwo;
	}

	/**
	 * This method is to set the option two of first question of the survey
	 * 
	 * @param questionTwoOptionTwo
	 */
	public void setQuestionTwoOptionTwo(String questionTwoOptionTwo) {
		this.questionTwoOptionTwo = questionTwoOptionTwo;
	}

	/**
	 * This method is to get the option three of second question of the survey
	 * 
	 * @return questionTwoOptionThree
	 */
	public String getQuestionTwoOptionThree() {
		return questionTwoOptionThree;
	}

	/**
	 * This method is to set the option three of second question of the survey
	 * 
	 * @param questionTwoOptionThree
	 */
	public void setQuestionTwoOptionThree(String questionTwoOptionThree) {
		this.questionTwoOptionThree = questionTwoOptionThree;
	}

	/**
	 * This method is to get the option four of second question of the survey
	 * 
	 * @return questionTwoOptionFour
	 */
	public String getQuestionTwoOptionFour() {
		return questionTwoOptionFour;
	}

	/**
	 * This method is to set the option four of second question of the survey
	 * 
	 * @param questionTwoOptionFour
	 */
	public void setQuestionTwoOptionFour(String questionTwoOptionFour) {
		this.questionTwoOptionFour = questionTwoOptionFour;
	}

	/**
	 * This method is to get the option one of one question of the survey
	 * 
	 * @return questionOneOptionOne
	 */
	public String getQuestionOneOptionOne() {
		return questionOneOptionOne;
	}

	/**
	 * This method is to set the option one of one question of the survey
	 * 
	 * @param questionOneOptionOne
	 */
	public void setQuestionOneOptionOne(String questionOneOptionOne) {
		this.questionOneOptionOne = questionOneOptionOne;
	}

	/**
	 * This method is to get the option two of two question of the survey
	 * 
	 * @return questionOneOptionTwo
	 */
	public String getQuestionOneOptionTwo() {
		return questionOneOptionTwo;
	}

	/**
	 * This method is to set the option two of one question of the survey
	 * 
	 * @param questionOneOptionTwo
	 */
	public void setQuestionOneOptionTwo(String questionOneOptionTwo) {
		this.questionOneOptionTwo = questionOneOptionTwo;
	}

	/**
	 * This method is to get the option three of two question of the survey
	 * 
	 * @return questionOneOptionThree
	 */
	public String getQuestionOneOptionThree() {
		return questionOneOptionThree;
	}

	/**
	 * This method is to set the option three of one question of the survey
	 * 
	 * @param questionOneOptionThree
	 */
	public void setQuestionOneOptionThree(String questionOneOptionThree) {
		this.questionOneOptionThree = questionOneOptionThree;
	}

	/**
	 * This method is to get the option four of two question of the survey
	 * 
	 * @return questionOneOptionFour
	 */
	public String getQuestionOneOptionFour() {
		return questionOneOptionFour;
	}

	/**
	 * This method is to set the option four of one question of the survey
	 * 
	 * @param questionOneOptionFour
	 */
	public void setQuestionOneOptionFour(String questionOneOptionFour) {
		this.questionOneOptionFour = questionOneOptionFour;
	}

	/**
	 * This method is to get the question one
	 * 
	 * @return defaultQuestionOne
	 */
	public String getDefaultQuestionOne() {
		return defaultQuestionOne;
	}

	/**
	 * This method is to set the question one
	 * 
	 * @param defaultQuestionOne
	 */
	public void setDefaultQuestionOne(String defaultQuestionOne) {
		this.defaultQuestionOne = defaultQuestionOne;
	}

	/**
	 * This method is to get the question one
	 * 
	 * @return defaultQuestionTwo
	 */
	public String getDefaultQuestionTwo() {
		return defaultQuestionTwo;
	}

	/**
	 * This method is to set the question two
	 * 
	 * @param defaultQuestionTwo
	 */
	public void setDefaultQuestionTwo(String defaultQuestionTwo) {
		this.defaultQuestionTwo = defaultQuestionTwo;
	}

	/**
	 * This method is to get the question one
	 * 
	 * @return defaultQuestionThree
	 */
	public String getDefaultQuestionThree() {
		return defaultQuestionThree;
	}

	/**
	 * This method is to set the question three
	 * 
	 * @param defaultQuestionThree
	 */
	public void setDefaultQuestionThree(String defaultQuestionThree) {
		this.defaultQuestionThree = defaultQuestionThree;
	}

	/**
	 * This method is to get the question four
	 * 
	 * @return defaultQuestionFour
	 */
	public String getDefaultQuestionFour() {
		return defaultQuestionFour;
	}

	/**
	 * This method is to set the question four
	 * 
	 * @param defaultQuestionFour
	 */
	public void setDefaultQuestionFour(String defaultQuestionFour) {
		this.defaultQuestionFour = defaultQuestionFour;
	}

	/**
	 * This method is to get the question one
	 * 
	 * @return defaultQuestionFive
	 */
	public String getDefaultQuestionFive() {
		return defaultQuestionFive;
	}

	/**
	 * This method is to set the question five
	 * 
	 * @param defaultQuestionFive
	 */
	public void setDefaultQuestionFive(String defaultQuestionFive) {
		this.defaultQuestionFive = defaultQuestionFive;
	}

	private String distributedTo;

	/**
	 * This method is to get the distributed name
	 * 
	 * @return distributedTo
	 */
	public String getdistributedTo() {
		return distributedTo;
	}

	/**
	 * This method is to set the distributed name
	 * 
	 * @param distributedTo
	 */
	public void setdistributedTo(String distributedTo) {
		this.distributedTo = distributedTo;
	}

	private String responses;

	/**
	 * This method is to get the to check the response status
	 * 
	 * @return responses
	 */
	public String getResponses() {
		return responses;
	}

	/**
	 * This method is to set the to check the response status
	 * 
	 * @param responses
	 */
	public void setResponses(String responses) {
		this.responses = responses;
	}

	@Override
	public String toString() {
		return " [name=" + name + ", description=" + description + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", defaultQuestion01=" + defaultQuestionOne + ", q1option1=" + questionOneOptionOne + ", q1option2="
				+ questionOneOptionTwo + ", q1option3=" + questionOneOptionThree + ", q1option4="
				+ questionOneOptionFour + ", defaultQuestion02=" + defaultQuestionTwo + ", q2option1="
				+ questionTwoOptionOne + ", q2option2=" + questionTwoOptionTwo + ", q2option3=" + questionTwoOptionThree
				+ ", q2option4=" + questionTwoOptionFour + ", defaultQuestion03=" + defaultQuestionThree
				+ ", defaultQuestion04=" + defaultQuestionFour + ", defaultQuestion05=" + defaultQuestionFive
				+ ", distributedTo=" + distributedTo + "]";
	}

}
