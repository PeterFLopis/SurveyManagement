package com.capgemini.surveyms.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.factory.Factory;

/**
 * 
 * The RespondentLoginRepository class contains the Login credentials of the
 * Respondent.
 *
 */
public class RespondentLoginRepository {

	public static List<RespondentBean> loginOfRespondent = new ArrayList<RespondentBean>();

	public List<RespondentBean> respondentTable() {
		List<RespondentBean> respondent = new ArrayList<RespondentBean>();
		RespondentBean respondentBeanOne = Factory.getRespondentBeanInstance();
		respondentBeanOne.setUserName("respondent");
		respondentBeanOne.setPassword("respondent");
		respondent.add(respondentBeanOne);

		RespondentBean respondentBeanTwo = Factory.getRespondentBeanInstance();

		respondentBeanTwo.setUserName("peter");
		respondentBeanTwo.setPassword("peter");
		respondent.add(respondentBeanTwo);

		RespondentBean respondentBeanThree = Factory.getRespondentBeanInstance();
		respondentBeanThree.setUserName("lopis");
		respondentBeanThree.setPassword("lopis");
		respondent.add(respondentBeanThree);

		RespondentBean respondentBeanFour = Factory.getRespondentBeanInstance();
		respondentBeanFour.setUserName("francis");
		respondentBeanFour.setPassword("francis");
		respondent.add(respondentBeanFour);

		RespondentBean respondentBeanFive = Factory.getRespondentBeanInstance();
		respondentBeanFive.setUserName("user");
		respondentBeanFive.setPassword("user");

		respondent.add(respondentBeanFive);
		RespondentBean respondentBeanSix = Factory.getRespondentBeanInstance();
		respondentBeanSix.setUserName("virat");
		respondentBeanSix.setPassword("virat");

		respondent.add(respondentBeanSix);

		loginOfRespondent.addAll(respondent);
		return loginOfRespondent;
	}
}