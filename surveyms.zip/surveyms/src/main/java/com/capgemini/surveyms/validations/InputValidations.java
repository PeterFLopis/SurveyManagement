package com.capgemini.surveyms.validations;

public interface InputValidations {
	public boolean choiceOneToTwo(String choice);

	public boolean choiceOneToThree(String id);

	public boolean choiceOneToFour(String choice);

	public boolean choiceOneToSix(String id);

	public boolean nameValidation(String name);

	public boolean passwordValidation(String passcode);

	public boolean date(String date);

	public boolean lineInput(String answer);

	public boolean answerValidationForTwoFiftyCharacters(String answer);

	public boolean answerValidationFourThousandCharacters(String answer);

}
