package com.capgemini.surveyms.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.surveyms.bean.AdminBean;
import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyorBean;
import com.capgemini.surveyms.exception.InvalidRespondentException;
import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.repository.AdminLoginRepository;
import com.capgemini.surveyms.service.Service;

/**
 * 
 * The AdminController class implements the administration module. Administrator
 * will be able to perform all the operations performed by surveyor and
 * respondent.Admin can login as Surveyor, Respondent and can view Surveyors,
 * Respondents and add new Respondents.
 */
public class AdminController {

	public static Service adminService = Factory.getServiceInstance();
	public static final List<AdminBean> adminLoginList = new AdminLoginRepository().adminTable();
	static final Logger logger = Logger.getLogger(AdminController.class);
	public static final Scanner scanner = new Scanner(System.in);

	/**
	 * this method @adminLogin will ask to login the administrator to perform his
	 * operations If login condition satisfies it goes further else it exits the
	 * program.
	 * 
	 * 
	 * @throws IOException
	 */
	public void adminLogin() {

		Properties property = new Properties();
		try {

			property.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		String AdminUserName = property.getProperty("adminName");
		String AdminPassword = property.getProperty("adminPassword");

		boolean loginCredentials = adminService.adminLogin(AdminUserName, AdminPassword);
		if (loginCredentials) {

			logger.info("WELCOME Admin :");
			adminOperations(new AdminBean());
		} else {

			logger.info("Admin Login failed.\n" + RespondentController.LINE + "\n");
			System.exit(0);
		}
	}

	/**
	 * This method @adminOperations displays the operations which are performed by
	 * the administrator. Administration here can Login as Surveyor and Respondent.
	 * Administration can also view surveyor and respondent details and can add new
	 * Respondents.
	 * 
	 * @param adminBean
	 * @throws InvalidRespondentException
	 */
	public boolean adminOperations(AdminBean adminBean) {

		logger.info(RespondentController.LINE
				+ "\n\nPlease select your Choice:\n(ex: Press '1' if you want to Login as Surveyor)\n"
				+ RespondentController.LINE + "\n");

		logger.info("1: Login as Surveyor.");
		logger.info("2: Login as Respondent.");
		logger.info("3: View Surveyor details.");
		logger.info("4. View Respondent details.");
		logger.info("5. Add New Respondent.");
		logger.info("6. Exit.\n" + RespondentController.LINE + "\n");

		String choice = scanner.nextLine();
		while (!adminService.choiceOneToSix(choice)) {

			logger.info("please enter valid Choice between 1 and 6");
			choice = scanner.nextLine();

		}
		int adminChoice = Integer.parseInt(choice);
		switch (adminChoice) {

		case 1:
			SurveyorController surveyorLogin = Factory.getSurveyorControllerInstance();
			surveyorLogin.surveyorOperation(new SurveyorBean());
			break;
		case 2:
			RespondentController respondentLogin = Factory.getRespondentControllerInstance();
			respondentLogin.respondentLogin(new RespondentBean());
			break;
		case 3:
			boolean surveyorPresent = adminService.adminViewSurveyor();
			if (surveyorPresent) {
				logger.info("No surveyors to display");
				adminOperations(new AdminBean());
			} else {

				logger.info("The details of Surveyor are:\n" + RespondentController.LINE + "\n");
				for (SurveyorBean surveyorLoginDetails : SurveyorController.surveyorLoginList) {

					logger.info("SURVEYOR " + (SurveyorController.surveyorLoginList.indexOf(surveyorLoginDetails) + 1)
							+ "\nName     : " + surveyorLoginDetails.getUserName() + "  \nPassword : "
							+ surveyorLoginDetails.getPassword() + "\n");
				}
				adminOperations(new AdminBean());
			}
			break;
		case 4:
			boolean respondentPresent = adminService.viewRespondentPresent();
			if (respondentPresent) {
				logger.info("No Respondents to display");
				adminOperations(new AdminBean());

			} else {
				logger.info("The Details of Respondents present are:\n" + RespondentController.LINE + "\n");
				for (RespondentBean respondentLoginDetails : RespondentController.loginOfRespondent) {
					logger.info(
							"RESPONDENT " + (RespondentController.loginOfRespondent.indexOf(respondentLoginDetails) + 1)
									+ ": \nName     : " + respondentLoginDetails.getUserName() + "  \nPassword : "
									+ respondentLoginDetails.getPassword() + "\n");
				}
				adminOperations(new AdminBean());
			}
			break;
		case 5:
			boolean respondentIsPresent = adminService.viewRespondentPresent();
			if (respondentIsPresent) {
				logger.info("Add new Respondents here");

			} else {
				logger.info(
						"The respondent names which are already present are :\n(You cannot add the names which are already present)\n"
								+ RespondentController.SEMILINE);

			}
			for (RespondentBean respondentLoginDetails : RespondentController.loginOfRespondent) {
				logger.info(RespondentController.loginOfRespondent.indexOf(respondentLoginDetails) + 1 + ". "
						+ respondentLoginDetails.getUserName());
			}

			logger.info(
					"\n[The Respondent name should not contain any spaces,number and special characters.]\n(ex:Peter,peter)");

			logger.info("Enter the Name of Respondent you want to add :");
			String newRespondentName = scanner.nextLine();

			while (!adminService.nameValidations(newRespondentName)) {
				logger.info("please enter valid Respondent Name\n(ex: Peter )");
				newRespondentName = scanner.nextLine();
			}

			logger.info("Enter Password of Respondent :\n(Password should not contain spaces. ex: abc)");
			String newRespondentPassword = scanner.nextLine();

			while (!adminService.passwordVerification(newRespondentPassword)) {
				logger.info("please enter valid Respondent Password\n(ex: Peter )");
				newRespondentPassword = scanner.nextLine();
			}
			try {
				boolean check = adminService.addNewRespondent(newRespondentName, newRespondentPassword);
				if (check) {

					logger.info("Respondent '" + newRespondentName + "' added successfully !!!");
				} else {
					logger.info("Respondent not added, Respondent with name is already Present");
				}
			} catch (InvalidRespondentException e) {
				logger.info("Respondent with this name is already present");
				adminOperations(new AdminBean());
				break;
			}
			adminOperations(new AdminBean());
			break;
		case 6:
			logger.info("Thank You.\nPlease Exit the Screen.");
			System.exit(0);
			break;
		default:
			logger.info("Enter valid choice");
		}
		logger.info(RespondentController.LINE);

		return false;
	}
}
