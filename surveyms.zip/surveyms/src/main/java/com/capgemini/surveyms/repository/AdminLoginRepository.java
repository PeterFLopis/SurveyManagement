package com.capgemini.surveyms.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveyms.bean.AdminBean;
import com.capgemini.surveyms.factory.Factory;
/**
 * 
 * The AdminLoginRepository class contains the Login credentials of the Administrator.
 *
 */
public class AdminLoginRepository {

	public static List<AdminBean> adminLogList = new ArrayList<AdminBean>();

	public List<AdminBean> adminTable() {

		AdminBean adminBean = Factory.getAdminBeanInstance();
		adminBean.setUserName("admin");
		adminBean.setPassword("admin");
		adminLogList.add(adminBean);

		return adminLogList;
	}
}
