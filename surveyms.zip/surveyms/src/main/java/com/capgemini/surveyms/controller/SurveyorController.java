package com.capgemini.surveyms.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.validations.InputValidations;
import com.capgemini.surveyms.service.Service;
import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.bean.SurveyorBean;
import com.capgemini.surveyms.exception.InvalidRespondentException;
import com.capgemini.surveyms.exception.SurveyNotFoundException;
import com.capgemini.surveyms.repository.SurveyRepository;
import com.capgemini.surveyms.repository.SurveyorLoginRepository;

/**
 * SurveyorController is a class which manages all the operations of the
 * surveyor like creating,view and deleting new surveys.It can also update the
 * survey only if it is not distributed.Surveyor can distribute survey, Can also
 * be able to view responses received for the survey.
 * 
 * @author Peter
 *
 */
public class SurveyorController {
	public static Service surveyorService = Factory.getServiceInstance();
	int flag = 0;
	static final Logger log = Logger.getLogger(SurveyorController.class);
	public static final List<SurveyorBean> surveyorLoginList = new SurveyorLoginRepository().surveyorTable();
	public static final List<SurveyBean> surveyList = new SurveyRepository().surveyTable();
	Scanner scanner = new Scanner(System.in);
	static final String OPTIONS = "Your option should not contain any number in it.\nEx:One)";
	static final String QUESTIONVALIDATE = "Your question should not contain any number in it.\nEx:How much do you rate this product on the scale of Five?)";

	/**
	 * surveyorLoginProcess() is used for the Login of surveyor. If the surveyor is
	 * present he will continue else throws surveyor not present.
	 * 
	 * @throws IOException
	 */
	public void surveyorLoginProcess() {
		Properties property = new Properties();
		try {
			property.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			log.error(e.getMessage());
		}
		String SurveyorUsername = property.getProperty("surveyorName");
		String SurveyorPassword = property.getProperty("surveyorPassword");

		boolean loginCredentials = surveyorService.surveyorLogin(SurveyorUsername, SurveyorPassword);
		if (loginCredentials) {
			log.info(" Surveyor Login Successful\n" + RespondentController.LINE);

			surveyorOperation(new SurveyorBean());
		} else {
			log.info("Surveyor Login failed.\n" + RespondentController.LINE + "\n");
			System.exit(0);

		}
	}

	/**
	 * surveyorOperation method is used to perform surveyor operations
	 * 
	 * @param surveyor
	 */
	public boolean surveyorOperation(SurveyorBean surveyor) {
		log.info(RespondentController.LINE + "\nSelect your choice\n(ex: Press '1' to perform 'Survey Operations')\n"
				+ "\n1. Survey Operations.\n   (Create Survey, View Survey and Delete survey)\n");

		log.info("2. Update Survey.\n   (If Survey is not distributed)\n");

		log.info("3. Distribute Survey.\n");

		log.info("4. Distributed Survey Responses.\n   (View Survey Responses and Pending Surveys)\n");

		log.info("5. Back. \n   (Login as Admin,Surveyor,Respondent)\n");

		log.info("6. Exit.\n" + RespondentController.LINE);

		String choice = scanner.nextLine();
		while (!surveyorService.choiceOneToSix(choice)) {
			log.info("please enter valid choice [1-6] ");
			choice = scanner.nextLine();
		}
		int choiceInteger = Integer.parseInt(choice);

		switch (choiceInteger) {

		case 1:
			createViewDelete();
			break;
		case 2:
			surveyUpdate();
			break;
		case 3:
			distributeSurvey();
			break;
		case 4:
			log.info("1.View Survey Responses");
			log.info("2.View Pending Surveys");
			String distributedResponse = scanner.nextLine();
			while (!surveyorService.choiceOneToTwo(distributedResponse)) {
				log.info("please enter valid choice [1-2] ");
				distributedResponse = scanner.nextLine();
			}
			int distributedResponseInteger = Integer.parseInt(distributedResponse);
			switch (distributedResponseInteger) {
			case 1:
				viewSurveyResponses();
				break;
			case 2:
				pendingSurveyToRespond();
				break;
			default:
				log.info("Enter valid choice");
			}
			break;
		case 5:
			log.info(RespondentController.SELECTION + "\n" + RespondentController.LINE);
			RespondentController back = Factory.getRespondentControllerInstance();
			back.backToLogin();
			break;
		case 6:
			log.info("Thank You, Please exit the Screen");
			System.exit(0);
			break;
		default:
		}
		return true;
	}

	/**
	 * createViewDelete method is used to perform Create,View,delete operations on
	 * Surveys
	 * 
	 */
	public void createViewDelete() {
		log.info("Select your choice\n" + "(ex: Press '1' to 'Create Survey')\n" + RespondentController.LINE
				+ "\n1. Create  Survey.\n  (Create a new Survey questionarie by filling the form \n  field's values for survey titles,description,questions) \n");
		log.info("2. View  Survey.\n  (View the list of Surveys Present)\n");
		log.info("3. Delete Survey.\n  (Delete the Surveys from the List)\n");
		log.info("4. Back\n  (Survey Operations)\n" + RespondentController.LINE);
		String choiceForOperations = scanner.nextLine();

		while (!surveyorService.choiceOneToFour(choiceForOperations)) {
			log.info("please enter valid id Choice [1-4]");
			choiceForOperations = scanner.nextLine();
		}
		int choiceforOperations = Integer.parseInt(choiceForOperations);

		switch (choiceforOperations) {
		case 1:
			surveyAdd(new SurveyBean());
			break;
		case 2:
			surveyView();
			break;

		case 3:
			surveyDelete();
			break;
		case 4:
			surveyorOperation(new SurveyorBean());
			break;
		default:
			log.info("Enter valid choice");
		}
	}

	/**
	 * surveyAdd method is used to create new surveys.
	 * 
	 * @param surveyList
	 * @throws SurveyNotFoundException
	 */
	public boolean surveyAdd(SurveyBean surveyList) {

		boolean viewSurveyOne = surveyorService.viewSurvey();
		if (viewSurveyOne) {
			log.info("There are no surveys present, You can give any name for Survey\n");
		}

		else {
			log.info("List of surveys present are:\n(You cannot select existing survey names)\n"
					+ RespondentController.LINE);
			surveyNames();
		}

		log.info("Enter Name of survey. ( ex: peter)");
		String surveyName = scanner.nextLine();
		while (!surveyorService.nameValidations(surveyName)) {
			log.info("Please enter  valid Name : (ex: peter)");
			surveyName = scanner.nextLine();
		}
		try {
			boolean checkSurvey = surveyorService.checkSurvey(surveyName);
			if (checkSurvey) {

				log.info("'" + surveyName + "' Survey  is already present, Please select different name.\n"
						+ RespondentController.LINE);

				createViewDelete();

			} else {
				String distributePeter = distributeNowOrLater(surveyName);
				List<LocalDate> forDateInput = dateInput();
				List<String> inputs = questionarieInputs();
				boolean addSurvey = surveyorService.createSurvey(surveyName, inputs.get(13), forDateInput.get(0),
						forDateInput.get(1), inputs.get(0), inputs.get(1), inputs.get(2), inputs.get(3), inputs.get(4),
						inputs.get(5), inputs.get(6), inputs.get(7), inputs.get(8), inputs.get(9), inputs.get(10),
						inputs.get(11), inputs.get(12), distributePeter);
				if (!addSurvey) {
					log.info("Survey  Not Added  ");
					surveyorOperation(new SurveyorBean());

				} else {
					log.info("survey added  Successfully.");
					surveyorOperation(new SurveyorBean());
				}
			}
		} catch (SurveyNotFoundException e) {
			log.info("Survey with this name is already present");
		}

		return true;
	}

	/**
	 * surveyView method is used to view the existing surveys.
	 * 
	 */
	public List<SurveyBean> surveyView() {

		log.info("You can view survey here  !!! ");
		log.info("In what format you want to display ?\n(ex: Press 1. to 'view all details'\n"
				+ RespondentController.SEMILINE);
		log.info("1. View all Names of Surveys present.");
		log.info("2. View all details.");
		log.info("3. Back");
		String choice = scanner.nextLine();

		while (!surveyorService.choiceOneToThree(choice)) {
			log.info("Enter choice between 1 to 3");
			choice = scanner.nextLine();
		}
		int choiceInteger = Integer.parseInt(choice);

		switch (choiceInteger) {
		case 1:
			boolean viewSurveyOne = surveyorService.viewSurvey();
			if (viewSurveyOne) {
				log.info(RespondentController.SEMILINE + "\nNo Survey names to display\n");
				surveyorOperation(new SurveyorBean());
			} else {
				log.info("Your surveys names are :\n" + RespondentController.SEMILINE);
				surveyNames();
			}
			createViewDelete();
			break;
		case 2:
			log.info("Your surveys are:");
			boolean viewsurveyTwo = surveyorService.viewSurvey();
			if (viewsurveyTwo) {
				log.info("Empty , No surveys present");
			} else {
				for (SurveyBean surveysList : SurveyorController.surveyList) {

					log.info("Survey Details\n" + RespondentController.SEMILINE + "\nSurvey Name        : "
							+ surveysList.getName());
					log.info("Survey Description : " + surveysList.getDescription());
					log.info("Survey Start Date	 : " + surveysList.getStartDate());
					log.info("Survey End Date  : " + surveysList.getEndDate());
					log.info("\nQuestion 01 :" + surveysList.getDefaultQuestionOne());
					log.info("Options :\n" + surveysList.getQuestionOneOptionOne() + "\n"
							+ surveysList.getQuestionOneOptionTwo());
					log.info(surveysList.getQuestionOneOptionThree() + "\n" + surveysList.getQuestionOneOptionFour());

					log.info("\nQuestion 02 :" + surveysList.getDefaultQuestionTwo());
					log.info("Options :\n" + surveysList.getQuestionTwoOptionOne() + "\n"
							+ surveysList.getQuestionTwoOptionTwo());
					log.info(surveysList.getQuestionTwoOptionThree() + "\n" + surveysList.getQuestionTwoOptionFour());

					log.info("\nQuestion 03 :" + surveysList.getDefaultQuestionThree() + "\n");
					log.info("Question 04 :" + surveysList.getDefaultQuestionFour() + "\n");
					log.info("Question 05 :" + surveysList.getDefaultQuestionFive() + "\n");
					if (surveysList.getdistributedTo().contentEquals("")) {
						log.info("Survey not yet distributed\n");
					} else {
						log.info("Survey distributed to '" + surveysList.getdistributedTo() + "'\n");
					}
					boolean checkZero = surveyorService.checkZero(surveysList);
					if (checkZero) {
						log.info("Survey is not yet responded\n" + RespondentController.LINE);
					} else {
						log.info("Survey is responded\n" + RespondentController.LINE);
					}
				}
			}
			createViewDelete();
			break;

		case 3:
			createViewDelete();
			break;
		default:
			log.info("Enter valid choice\n");
		}
		return SurveyorController.surveyList;

	}

	/**
	 * surveyDelete method is used to delete the existing surveys.
	 * 
	 * @throws SurveyNotFoundException
	 */
	public boolean surveyDelete() {
		boolean surveyNotPresent = surveyorService.viewSurvey();

		if (surveyNotPresent) {
			log.info("Empty, No surveys to display\n" + RespondentController.SEMILINE);
			createViewDelete();

		} else {
			log.info("You can Delete  your surveys here: \n");

			log.info("Your surveys names are:");
			surveyNames();
		}
		log.info("Enter survey name which you want to delete\n(ex: cricket)\n" + RespondentController.SEMILINE);

		String surveyName = scanner.nextLine();

		while (!surveyorService.nameValidations(surveyName)) {
			log.info("please enter valid survey name");
			surveyName = scanner.nextLine();
		}

		try {
			boolean deleteSurvey = surveyorService.deleteSurvey(surveyName);
			if (deleteSurvey) {
				log.info("'" + surveyName + "' Survey deleted sucessfully\n" + RespondentController.LINE);
				createViewDelete();
			} else {
				log.info("'" + surveyName + "' Survey is not present or it is already deleted\n"
						+ RespondentController.LINE);
				createViewDelete();
			}
		} catch (SurveyNotFoundException e) {
			log.error(e.getMessage());
			createViewDelete();
		}

		return false;

	}

	/**
	 * surveyUpdate method is used to update the existing surveys.
	 * 
	 * @throws SurveyNotFoundException
	 */
	public boolean surveyUpdate() {

		InputValidations inputValidations = Factory.getInputValidationInstance();
		int checkPendingSurveys = 0;
		for (SurveyBean surveyList : SurveyorController.surveyList) {

			if (surveyList.getdistributedTo().contentEquals("")) {
				checkPendingSurveys++;
			}
		}
		if (checkPendingSurveys == 0) {
			log.info("No Surveys to update, All surveys are distributed");
			surveyorOperation(new SurveyorBean());
		} else {
			log.info("The survey you can update are:\n(Remaining surveys are distributed)\n");
			for (SurveyBean surveyBeanTwo : SurveyorController.surveyList) {
				if (surveyBeanTwo.getdistributedTo().contentEquals("")) {
					log.info(surveyBeanTwo.getName());
				}

			}
			log.info(RespondentController.LINE
					+ "\nPlease Enter Survey Name from the above list which you want to edit");
			String surveyEdit = scanner.nextLine();
			while (!inputValidations.nameValidation(surveyEdit)) {
				log.info("please enter valid surveyname");
				surveyEdit = scanner.nextLine();
			}

			for (SurveyBean surveyBeans : SurveyorController.surveyList) {
				boolean updatingSurvey = surveyorService.editsurvey(surveyEdit, surveyBeans);

				if (updatingSurvey) {

					if (surveyBeans.getdistributedTo().length() == 0) {
						log.info("You  can update this survey");

						flag++;
						log.info("Updating ...\n" + RespondentController.SEMILINE);

						log.info("Enter Name of survey (Format: Lower case. ex: peter)");
						String surveyName = scanner.nextLine();
						while (!surveyorService.nameValidations(surveyName)) {
							log.info("please  valid name");
							surveyName = scanner.nextLine();
						}

						int count = 0;
						for (SurveyBean checkSurveyPresent : SurveyorController.surveyList) {
							if (checkSurveyPresent.getName().contentEquals(surveyName)) {
								count++;
							}
						}
						if (count != 0) {

							log.info("Survey with this name is already present\n");

							surveyUpdate();

						} else {

							surveyBeans.setName(surveyEdit.replaceAll(surveyEdit, surveyName));
							String distributePeter = distributeNowOrLater(surveyName);
							List<LocalDate> dateInputs = dateInput();
							List<String> questionarie = questionarieInputs();
							surveyBeans.setName(surveyName);
							surveyBeans.setDescription(questionarie.get(13));
							surveyBeans.setStartDate(dateInputs.get(0));
							surveyBeans.setEndDate(dateInputs.get(1));
							surveyBeans.setDefaultQuestionOne(questionarie.get(0));
							surveyBeans.setQuestionOneOptionOne(questionarie.get(1));
							surveyBeans.setQuestionOneOptionTwo(questionarie.get(2));
							surveyBeans.setQuestionOneOptionThree(questionarie.get(3));
							surveyBeans.setQuestionOneOptionFour(questionarie.get(4));

							surveyBeans.setDefaultQuestionTwo(questionarie.get(5));
							surveyBeans.setQuestionTwoOptionOne(questionarie.get(6));
							surveyBeans.setQuestionTwoOptionTwo(questionarie.get(7));
							surveyBeans.setQuestionTwoOptionThree(questionarie.get(8));
							surveyBeans.setQuestionTwoOptionFour(questionarie.get(9));

							surveyBeans.setDefaultQuestionThree(questionarie.get(10));
							surveyBeans.setDefaultQuestionFour(questionarie.get(11));
							surveyBeans.setDefaultQuestionFive(questionarie.get(12));
							surveyBeans.setdistributedTo(distributePeter);
							surveyBeans.setResponses("0");

							log.info("Survey Updated");
							flag++;
							surveyorOperation(new SurveyorBean());

						}

					}

					else {

						log.info("");
						log.info(
								"You cannot update this survey\n Please enter valid name:\n[ The existing and non-distributed survey only can be modified]");
						log.info(RespondentController.LINE + "\n");

						surveyorOperation(new SurveyorBean());

					}
				}
			}
			try {
				if (flag == 0) {
					throw new SurveyNotFoundException();
				}
			} catch (SurveyNotFoundException e) {
				log.error(e.getMessage());
				surveyorOperation(new SurveyorBean());
			}
		}
		return false;
	}

	/**
	 * distributeSurvey method is used to distribute the existing surveys.
	 * 
	 * @throws SurveyNotFoundException
	 */
	public void distributeSurvey() {
		int checkPendingSurveys = 0;
		for (SurveyBean surveyList : SurveyorController.surveyList) {
			boolean contentIsZero = surveyorService.contentIsNull(surveyList);

			if (contentIsZero) {
				checkPendingSurveys++;
			}
		}
		if (checkPendingSurveys == 0) {
			log.info("no pending surveys, all surveys are distributed");
			surveyorOperation(new SurveyorBean());
		} else {
			log.info("Pending surveys to be distributed are:\n" + RespondentController.SEMILINE);

			for (SurveyBean surveyList : SurveyorController.surveyList) {
				boolean contentIsZero = surveyorService.contentIsNull(surveyList);

				if (contentIsZero) {
					log.info(surveyList.getName());
				}
			}
			log.info(RespondentController.SEMILINE + "\nEnter survey name u want to distribute from the above list");
			String surveyName = scanner.nextLine();
			int surveyAlreadyDistributed = 0;
			int surveyNotPresent = 0;
			for (SurveyBean surveyList : SurveyorController.surveyList) {
				if (surveyList.getName().contentEquals(surveyName)) {
					surveyNotPresent++;
				}
				while ((surveyList.getName().contentEquals(surveyName))
						&& (surveyList.getdistributedTo().contentEquals(""))) {
					String distributePeter = distributionProcess(surveyName);
					surveyList.setdistributedTo(distributePeter);
					log.info("Distributed successfully");
					surveyorOperation(new SurveyorBean());
					surveyAlreadyDistributed++;
				}

			}
			if (surveyNotPresent == 0) {
				log.info("'" + surveyName + "' Survey is not present");
				surveyorOperation(new SurveyorBean());

			} else if (surveyAlreadyDistributed == 0) {
				log.info("'" + surveyName + "' survey is already distributed");
				surveyorOperation(new SurveyorBean());
			}
		}
	}

	/**
	 * viewAllResponses method is used to view all responses for the surveys.
	 * 
	 */
	public List<String> viewSurveyResponses() {

		boolean viewSurveyOne = surveyorService.viewResponseSurveyOne();
		if (viewSurveyOne) {
			log.info("No Survey Responses to display.");
			surveyorOperation(new SurveyorBean());
		} else {

			log.info("Responses of respondents to your Surveys are viewed here !!! ");

			for (String respondedList : RespondentController.surveyResponseList) {
				log.info(respondedList);
			}
			log.info(RespondentController.SEMILINE);
			surveyorOperation(new SurveyorBean());
		}
		return RespondentController.surveyResponseList;

	}

	/**
	 * pendingSurveyToRespond method is used to view all pending surveys to respond.
	 * 
	 */
	public void pendingSurveyToRespond() {
		log.info("Pending survey to respond are :\n" + RespondentController.SEMILINE);

		for (SurveyBean surveyLists : SurveyorController.surveyList) {
			boolean response = surveyorService.response(surveyLists);
			if (response) {
				log.info(surveyLists.getName());
			}
		}
		log.info(RespondentController.SEMILINE);
		surveyorOperation(new SurveyorBean());
	}

	/**
	 * distributeNowOrLater method is used to distribute the survey to respondent
	 * based on the requirement.
	 * 
	 * @param surveyName
	 */
	public String distributeNowOrLater(String surveyName) {
		log.info("Do you want to distribute the survey ?\n" + RespondentController.SEMILINE);
		log.info("Press 1 to Distribute now");
		log.info("Press 2 to Distribute Later\n" + RespondentController.SEMILINE);
		String distribution = scanner.nextLine();
		while (!surveyorService.choiceOneToTwo(distribution)) {
			log.info("1 or 2 ONLY");
			distribution = scanner.nextLine();
		}
		int distributionInteger = Integer.parseInt(distribution);
		String distributePeter;
		switch (distributionInteger) {

		case 1:
			distributePeter = distributionProcess(surveyName);
			break;
		case 2:
			distributePeter = "";
			break;
		default:
			distributePeter = "";

		}
		return distributePeter;
	}

	/**
	 * names method is used to view the names of surveys.
	 * 
	 */
	public void surveyNames() {
		for (SurveyBean surveyBeanLists : SurveyorController.surveyList) {

			log.info(surveyBeanLists.getName() + "\n");
		}
	}

	/**
	 * distributionProcess method is used to distribute the surveys to respondents.
	 * 
	 * @param surveyName
	 * @throws InvalidRespondentException
	 */
	String distributionProcess(String surveyName) {

		log.info("Names of respondents present are\n" + RespondentController.SEMILINE);

		for (RespondentBean respodentControl : RespondentController.loginOfRespondent) {
			log.info(respodentControl.getUserName());
		}

		log.info("Please enter Respondent name to whom you want to distribute : ");
		String distribute = scanner.nextLine();

		while (!surveyorService.nameValidations(distribute)) {
			log.info("Please enter  valid Name : (Format: Lower case. ex: peter)");
			distribute = scanner.nextLine();

		}

		for (SurveyBean surveyControls : SurveyorController.surveyList) {
			while (surveyControls.getdistributedTo().contentEquals(distribute)) {

				log.info("'" + distribute + "' already has a assigned Survey");
				log.info("Please give a respondent name which has no surveys distributed\n"
						+ RespondentController.SEMILINE);
				log.info("Enter Name of respondent. ( ex: respondent)");
				distribute = scanner.nextLine();

				while (!surveyorService.nameValidations(surveyName)) {
					log.info("Please enter  valid Name : (ex: respondent)");
					distribute = scanner.nextLine();
				}
			}
			try {
				int countDistributed = 0;
				for (RespondentBean respondentBean : RespondentController.loginOfRespondent) {
					if (respondentBean.getUserName().contentEquals(distribute)) {
						countDistributed++;
					}
				}
				if (countDistributed == 0) {
					throw new InvalidRespondentException();
				} else {

					for (SurveyBean surveyControl : SurveyorController.surveyList) {

						while (surveyControl.getdistributedTo().contentEquals(distribute)) {
							log.info("u cannot distribute to " + distribute + " ,  already has a survey distributed\n"
									+ RespondentController.SEMILINE);
							log.info("Please enter Respondent name to whom you want to distribute : ");
							distribute = scanner.nextLine();
							int countDistributing = 0;
							for (RespondentBean respondentBean : RespondentController.loginOfRespondent) {
								if (respondentBean.getUserName().contentEquals(distribute)) {
									countDistributing++;
								}
							}
							if (countDistributing == 0) {
								throw new InvalidRespondentException();
							}
						}
					}
				}
			} catch (InvalidRespondentException e) {
				log.error(e.getMessage());
				log.info("The survey can be distributed only to the exisiting respondents\n"
						+ RespondentController.LINE);
				surveyorOperation(new SurveyorBean());
			}
		}
		return distribute;
	}

	/**
	 * questionarieInputs method is used to take the question inputs.
	 * 
	 */
	public List<String> questionarieInputs() {

		log.info("Enter Description of Survey :\n(ex: description is a detailed account of certain aspects.)");
		String description = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(description)) {
			log.info("Please enter valid Description of Survey :\n(It should not contain any Numbers)");
			description = scanner.nextLine();
		}

		final String OPTION = "Enter Four options: ";
		log.info(
				"Please enter Question 01 :\n(ex: Please select one among four choices)\n(Question should not contain any numbers and special characters) ");
		String questionOne = scanner.nextLine();

		while (!surveyorService.surveyLineVerify(questionOne)) {
			log.info(QUESTIONVALIDATE);
			questionOne = scanner.nextLine();
		}

		log.info(OPTION);

		String optionOne = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(optionOne)) {
			log.info(OPTIONS);
			optionOne = scanner.nextLine();
		}
		String optionTwo = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(optionTwo)) {
			log.info(OPTIONS);
			optionTwo = scanner.nextLine();
		}
		String optionThree = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(optionThree)) {
			log.info(OPTIONS);
			optionThree = scanner.nextLine();
		}
		String optionFour = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(optionFour)) {
			log.info(OPTIONS);
			optionFour = scanner.nextLine();
		}

		log.info("Please enter Question 02 :(ex: Please select one among four choices) ");
		String questionTwo = scanner.nextLine();

		while (!surveyorService.surveyLineVerify(questionTwo)) {
			log.info(QUESTIONVALIDATE);
			questionTwo = scanner.nextLine();
		}
		log.info(OPTION);
		String option0One = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(option0One)) {
			log.info(OPTIONS);
			option0One = scanner.nextLine();
		}
		String option0Two = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(option0Two)) {
			log.info(OPTIONS);
			option0Two = scanner.nextLine();
		}
		String option0Three = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(option0Three)) {
			log.info(OPTIONS);

			option0Three = scanner.nextLine();
		}
		String option0Four = scanner.nextLine();
		while (!surveyorService.surveyLineVerify(option0Four)) {
			log.info(OPTIONS);
			option0Four = scanner.nextLine();
		}
		log.info("Please enter Question 03 : ");
		String questionThree = scanner.nextLine();

		while (!surveyorService.surveyLineVerify(questionThree)) {
			log.info(QUESTIONVALIDATE);
			questionThree = scanner.nextLine();
		}

		log.info("Please enter Question 04 : ");
		String questionFour = scanner.nextLine();

		while (!surveyorService.surveyLineVerify(questionFour)) {
			log.info(QUESTIONVALIDATE);
			questionFour = scanner.nextLine();
		}
		log.info("Please enter Question 05 : ");
		String questionFive = scanner.nextLine();

		while (!surveyorService.surveyLineVerify(questionFive)) {
			log.info(QUESTIONVALIDATE);
			questionFive = scanner.nextLine();
		}
		List<String> list = new ArrayList<String>();
		list.add(questionOne);
		list.add(optionOne);
		list.add(optionTwo);
		list.add(optionThree);
		list.add(optionFour);
		list.add(questionTwo);
		list.add(option0One);
		list.add(option0Two);
		list.add(option0Three);
		list.add(option0Four);
		list.add(questionThree);
		list.add(questionFour);
		list.add(questionFive);
		list.add(description);
		return list;
	}

	/**
	 * dateInput method is used to take the date inputs.
	 * 
	 */
	public List<LocalDate> dateInput() {
		LocalDate startDate = null;

		boolean check = true;
		while (check) {
			final String STARTDATE = "Enter Start date of Survey in format YYYY-MM-DD";
			log.info(STARTDATE);
			String dateStart = scanner.nextLine();
			while (!surveyorService.dateVerify(dateStart)) {
				log.info(STARTDATE);
				dateStart = scanner.nextLine();
			}
			try {
				startDate = LocalDate.parse(dateStart);

				while (startDate.isBefore(LocalDate.now())) {
					log.info("Start Date should be present date or furture date");
					dateStart = scanner.nextLine();
					while (!surveyorService.dateVerify(dateStart)) {
						log.info(STARTDATE);
						dateStart = scanner.nextLine();
					}
					startDate = LocalDate.parse(dateStart);
				}
				check = false;
			} catch (DateTimeParseException e) {
				log.error("Entered date is not present in the calender enter valid date like(yyyy-mm-dd)");
				check = true;
			}
		}
		LocalDate endDate = null;

		boolean checkTwo = true;
		while (checkTwo) {
			final String ENDDATE = "Enter End date of survey in format YYYY-MM-DD";
			log.info(ENDDATE);
			String dateEnd = scanner.nextLine();
			while (!surveyorService.dateVerify(dateEnd)) {
				log.info(ENDDATE);
				dateEnd = scanner.nextLine();
			}
			try {
				endDate = LocalDate.parse(dateEnd);
				while (endDate.isBefore(startDate)) {
					log.info("End Date should be after thr Start Date of the survey");
					dateEnd = scanner.nextLine();
					while (!surveyorService.dateVerify(dateEnd)) {
						log.info(ENDDATE);
						dateEnd = scanner.nextLine();
					}
					endDate = LocalDate.parse(dateEnd);
				}

				checkTwo = false;
			} catch (DateTimeParseException e) {
				log.error("Entered date is not present in the calender.\n enter valid date like(YYYY-MM-DD)");
				checkTwo = true;
			}
		}
		List<LocalDate> localDates = new ArrayList<>();
		localDates.add(startDate);
		localDates.add(endDate);
		return localDates;

	}

}
