package com.capgemini.surveyms.bean;

import java.io.Serializable;

/**
 * 
 * This is a Bean Class which contains The First Question Information which is
 * displayed for the respondent while Responding the survey Which contains
 * Private variables.
 * 
 * The Getter and Setter methods are to Get and Set the Variables.
 */
public class QuestionOneBean implements Serializable {
	public QuestionOneBean() {
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String answerOne;

	/**
	 * This Method getAnswerOne() Is Used Get the answer one
	 * 
	 * 
	 * @return answerOne
	 */
	public String getAnswerOne() {
		return answerOne;
	}

	/**
	 * This Method setAnswerOne() Is Used Get the answer one
	 * 
	 * 
	 * @param answerOne
	 */
	public void setAnswerOne(String answerOne) {
		this.answerOne = answerOne;
	}

	@Override
	public String toString() {
		return "QuestionOneBean [answerOne=" + answerOne + "]";
	}

}
