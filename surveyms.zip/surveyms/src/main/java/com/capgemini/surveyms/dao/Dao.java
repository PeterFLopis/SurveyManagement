package com.capgemini.surveyms.dao;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.surveyms.bean.SurveyBean;

public interface Dao {
	public boolean adminLogin(String adminName, String adminPassword);

	public boolean adminViewSurveyor();

	public boolean addNewRespondent(String newRespondentName, String newRespondentPassword);

	public boolean surveyorLogin(String surveyorUsername, String surveyorPassword);

	public boolean surveyAdd(SurveyBean surveybean);

	public boolean surveyView();

	public boolean deleteSurvey(String surve);

	public boolean surveyUpdate(String s, SurveyBean stringTwo);

	public boolean surveyResponseView();

	public boolean addSurvey(String surveyName);

	public boolean creatingSurvey(String surveyName, String description, LocalDate startdate, LocalDate enddate,
			String question0One, String option0One, String option0Two, String option0Three, String option0Four,
			String questionTwo, String optionOne, String optionTwo, String optionThree, String optionFour,
			String questionThree, String questionFour, String questionFive, String distribute);

	
	public boolean viewRespondentPresent();

	public boolean checkRespondentPresent(String userName);

	public boolean checkResponseStatus(String userName);

	public void setResponse(SurveyBean surveyLists, String setValue);

	public List<String> addResponses(String surveyName, String oneDetails, String twoDetails, String threeDetails,
			String fourDetails, String fiveDetails);

	public boolean checkZero(SurveyBean surveysList);

	public boolean contentIsNull(SurveyBean surveyList);

	public boolean response(SurveyBean surveyLists);

}
