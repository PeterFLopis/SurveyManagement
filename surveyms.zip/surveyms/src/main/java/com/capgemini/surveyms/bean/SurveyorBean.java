package com.capgemini.surveyms.bean;

import java.io.Serializable;

/**
 * 
 * This is a Bean Class which contains Surveyor Login Information Which contains
 * Private variables.
 * 
 * The Getter and Setter methods are to Get and Set the Variables.
 */
public class SurveyorBean implements Serializable {
	public SurveyorBean() {
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;

	/**
	 * This Method Is Used Get surveyor User Name
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * This Method Is Used Set surveyor User Name
	 * 
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 
	 * This Method Is Used To get surveyors password
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * This Method Is Used Set surveyor password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SurveyorBean [userName=" + userName + ", password=" + password + "]";
	}
	

}
