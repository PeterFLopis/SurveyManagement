package com.capgemini.surveyms.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * This is Implementation of Input Validation Interface and its abstract method
 * 
 * The methods checks the specific validations.
 */
public class InputValidationsImplementation implements InputValidations {

	Pattern pattern = null;
	Matcher matcher = null;

	@Override
	public boolean choiceOneToTwo(String choice) {
		pattern = Pattern.compile("[1-2]");
		matcher = pattern.matcher(choice);
		return (matcher.matches());
	}

	@Override
	public boolean choiceOneToFour(String choice) {
		pattern = Pattern.compile("[1-4]");
		matcher = pattern.matcher(choice);
		return (matcher.matches());
	}

	@Override
	public boolean choiceOneToSix(String choice) {

		pattern = Pattern.compile("[1-6]");
		matcher = pattern.matcher(choice);
		return (matcher.matches());
	}

	@Override
	public boolean choiceOneToThree(String choice) {
		pattern = Pattern.compile("[1-3]");
		matcher = pattern.matcher(choice);
		return (matcher.matches());
	}

	@Override
	public boolean nameValidation(String name) {
		pattern = Pattern.compile("[a-zA-Z\\\\s]+[\\\\s[[a-zA-Z]+]]*");
		matcher = pattern.matcher(name);
		return (matcher.matches());
	}

	@Override
	public boolean passwordValidation(String password) {
		pattern = Pattern.compile("[a-zA-Z0-9@!#$%^&*]+");
		matcher = pattern.matcher(password);
		return (matcher.matches());
	}

	@Override
	public boolean date(String date) {
		pattern = Pattern.compile("[0-9]{4}-(0[1-9]|1[0-2])-(3[0-1]|[1-2][0-9]|0[0-9])");
		matcher = pattern.matcher(date);
		return (matcher.matches());
	}

	@Override
	public boolean lineInput(String answer) {
		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]");
		matcher = pattern.matcher(answer);
		return (matcher.matches());
	}

	@Override
	public boolean answerValidationForTwoFiftyCharacters(String answer) {
		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*{1,250}");
		matcher = pattern.matcher(answer);
		return (matcher.matches());
	}

	@Override
	public boolean answerValidationFourThousandCharacters(String answer) {
		pattern = Pattern.compile("[a-zA-Z]+[\\s[[a-zA-Z]+]]*{1,4000}");
		matcher = pattern.matcher(answer);
		return (matcher.matches());
	}

}
