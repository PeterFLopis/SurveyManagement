package com.capgemini.surveyms.exception;

public class InvalidSurveyorException extends RuntimeException  {
	/**
	 * If surveyor is not present
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String message = "Surveyor  not found";
	public InvalidSurveyorException() {

	}

	public InvalidSurveyorException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
