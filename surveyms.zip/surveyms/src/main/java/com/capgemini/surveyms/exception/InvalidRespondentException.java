package com.capgemini.surveyms.exception;

public class InvalidRespondentException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String message = "_____________________\nRespondent  not found\nThe Respondent Name and Password should match with existing Login Credentials.\n_____________________";

	public InvalidRespondentException() {

	}

	public InvalidRespondentException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
