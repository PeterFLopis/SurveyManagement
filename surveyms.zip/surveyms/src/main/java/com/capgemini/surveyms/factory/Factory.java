package com.capgemini.surveyms.factory;

import com.capgemini.surveyms.bean.AdminBean;
import com.capgemini.surveyms.bean.QuestionOneBean;
import com.capgemini.surveyms.bean.QuestionTwoBean;
import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.bean.SurveyorBean;
import com.capgemini.surveyms.controller.AdminController;
import com.capgemini.surveyms.controller.RespondentController;
import com.capgemini.surveyms.controller.SurveyorController;
import com.capgemini.surveyms.dao.Dao;
import com.capgemini.surveyms.dao.DaoImplementation;
import com.capgemini.surveyms.repository.AdminLoginRepository;
import com.capgemini.surveyms.repository.RespondentLoginRepository;
import com.capgemini.surveyms.repository.SurveyRepository;
import com.capgemini.surveyms.repository.SurveyorLoginRepository;
import com.capgemini.surveyms.service.Service;
import com.capgemini.surveyms.service.ServiceImplementation;
import com.capgemini.surveyms.validations.InputValidations;
import com.capgemini.surveyms.validations.InputValidationsImplementation;

/**
 * Factory is a class where the object of every class and are created
 * By using the class name we can use the object whenever required.
 */

public class Factory {

	private Factory() {

	}

	public static Service getServiceInstance() {
		return new ServiceImplementation();
	}

	public static InputValidations getInputValidationInstance() {
		return new InputValidationsImplementation();
	}

	public static AdminBean getAdminBeanInstance() {
		return new AdminBean();

	}

	public static SurveyorBean getSurveyorBeanInstance() {
		return new SurveyorBean();
	}

	public static RespondentBean getRespondentBeanInstance() {
		return new RespondentBean();
	}

	public static QuestionOneBean getQuestionOneBeanInstance() {
		return new QuestionOneBean();
	}

	public static QuestionTwoBean getQuestionTwoBeanInstance() {
		return new QuestionTwoBean();
	}

	public static SurveyBean getSurveyBeanInstance() {
		return new SurveyBean();
	}

	public static Dao getDAOInstance() {
		return new DaoImplementation();
	}

	public static SurveyRepository getSurveyRepository() {
		return new SurveyRepository();

	}

	public static RespondentLoginRepository getRespondentRepository() {
		return new RespondentLoginRepository();

	}

	public static AdminLoginRepository getAdminRepository() {
		return new AdminLoginRepository();

	}

	public static SurveyorLoginRepository getSurveyorRepository() {
		return new SurveyorLoginRepository();
	}

	public static SurveyorController getSurveyorControllerInstance() {
		return new SurveyorController();
	}

	public static AdminController getAdminControllerInstance() {
		return new AdminController();
	}

	public static RespondentController getRespondentControllerInstance() {
		return new RespondentController();
	}

//	public static Controller getControllerInstance() {
//		return new Controller();
//	}

}
