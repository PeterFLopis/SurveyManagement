package com.capgemini.surveyms.service;

import java.time.LocalDate;
import java.util.List;

import com.capgemini.surveyms.bean.SurveyBean;

/**
 * AdminService Interface has abstract methods.
 */
public interface Service {
	/* admin */
	public boolean adminLogin(String adminName, String adminPassword);

	public boolean adminViewSurveyor();

	public boolean addNewRespondent(String newRespondentName, String newRespondentPassword);

	//
	public boolean surveyorLogin(String surveyorUsername, String surveyorPassword);

	public boolean checkSurvey(String surveyName);

	public boolean createSurvey(String surveyName, String description, LocalDate startdate, LocalDate enddate,
			String questionOne, String optionOne, String optionTwo, String optionThree, String optionFour,
			String questionTwo, String optionTwoOne, String optionTwoTwo, String optionTwoThree, String optionTwoFour,
			String questionThree, String questionFour, String questionFive, String distribute);

	public boolean viewSurvey();

	public boolean deleteSurvey(String survey);

	public boolean editsurvey(String survey, SurveyBean surveyBean);

	public boolean contentIsNull(SurveyBean surveyList);

	public boolean response(SurveyBean surveyLists);

	public boolean viewResponseSurveyOne();

	//

	/* respondent */
	public boolean viewRespondentPresent();

	public boolean checkRespondentPresent(String userName);

	public boolean checkResponseStatus(String userName);

	public void setResponse(SurveyBean surveyLists, String status);

	public List<String> addResponses(String surveyName, String oneDetails, String twoDetails, String threeDetails,
			String fourDetails, String fiveDetails);

	//
	public boolean respondentService(String choice);

	public boolean passwordVerification(String password);

	public boolean answerValidationTwoFiftyCharacters(String answer);

	public boolean answerValidationFourThousandCharacters(String answer);

	public boolean choiceOneToThree(String choice);

	public boolean choiceOneToTwo(String distributedResponse);

	public boolean choiceOneToFour(String choice);

	public boolean choiceOneToSix(String choice);

	public boolean nameValidations(String userName);

	public boolean surveyLineVerify(String name);

	public boolean dateVerify(String dateStart);

	public boolean validatePassword(String password);

	public boolean adminChoice(String option);

	public boolean checkZero(SurveyBean surveysList);

}
