package com.capgemini.surveyms.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.capgemini.surveyms.bean.QuestionOneBean;
import com.capgemini.surveyms.bean.QuestionTwoBean;
import com.capgemini.surveyms.bean.RespondentBean;
import com.capgemini.surveyms.bean.SurveyBean;
import com.capgemini.surveyms.exception.InvalidRespondentException;
import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.repository.RespondentLoginRepository;
import com.capgemini.surveyms.service.Service;
import com.capgemini.surveyms.validations.InputValidations;

/**
 * 
 * 
 * @author Peter
 * 
 * 
 *         The Respondent Controller class implements the login process of
 *         Respondent and also Respond the Survey assigned.He can also view the
 *         List of Survey responded.
 *
 */
public class RespondentController {
	Service respondentService = Factory.getServiceInstance();
	static final Logger log = Logger.getLogger(RespondentController.class);

	public static final List<RespondentBean> loginOfRespondent = new RespondentLoginRepository().respondentTable();

	public static final List<String> surveyResponseList = new ArrayList<String>();
	public static final String LINE = "________________________________________________________________";
	public static final String SEMILINE = "___________________________";
	public static final String DUPLICATE = "Please enter valid choice";
	public static final String VALIDCHOICE = "please enter valid choice between [1-4] ";
	public static List<String> listOfResponse;

	public static final String SELECTION = "Select your choice\n(ex: Press '1' to  Login Again\n1 : Login again as Respondent\n2 : Login as Admin\n3 : Login as Surveyor\n4 : Exit \n ";

	static Scanner scanner = new Scanner(System.in);
	InputValidations inputValidations = Factory.getInputValidationInstance();

	/**
	 * @method respondentLogin(RespondentBean respondentBean) will login as
	 *         respondent. If respondent is present it will ask to respond a survey
	 *         if he has not responded earlier.
	 * 
	 * @param respondentBean
	 * @throws InvalidRespondentException
	 */
	public boolean respondentLogin(RespondentBean respondentBean) {

		boolean respondentIsPresent = respondentService.viewRespondentPresent();
		if (respondentIsPresent) {
			log.info("No respondents are present, please ask the admin the add new respondents");
			log.info(LINE + "\n" + SELECTION + "\n" + LINE);
			backToLogin();

		} else {
			log.info(LINE + "\nWelcome to Respondent Login !!\n");
			log.info("Here you can Respond the assigned survey and View the list of responded survey\n");

			log.info("You want to login as?\n" + SEMILINE);

			for (RespondentBean respondentBeanOne : loginOfRespondent) {
				log.info(respondentBeanOne.getUserName());
			}

		}

		log.info(LINE
				+ "\n[The name should not contain any spaces,number and special characters.]\n\nEnter the Respondent User Name from the above list.\n(ex:peter)");
		String userName = scanner.nextLine();
		while (!respondentService.nameValidations(userName)) {
			log.info("please enter valid Respondent Name from the List (ex:peter)");
			userName = scanner.nextLine();
		}

		log.info("Enter your password \n(ex:peter)");
		String password = scanner.nextLine();
		while (!respondentService.passwordVerification(password)) {
			log.info("Please Enter Valid Password");
			password = scanner.nextLine();
		}
		try {
			int count = 0;
			for (RespondentBean respondentbeanTwo : RespondentController.loginOfRespondent) {
				if (respondentbeanTwo.getUserName().contentEquals(userName)
						&& respondentbeanTwo.getPassword().contentEquals(password)) {
					count++;
				}
			}

			if (count == 0) {
				throw new InvalidRespondentException();

			} else {
				surveyRespondedStatus(userName);
			}
		} catch (InvalidRespondentException e) {
			log.error(e.getMessage());
			log.info(SELECTION + "\n" + LINE);
			backToLogin();

			respondentLogin(new RespondentBean());
		}
		return false;

	}

	/**
	 * @surveyRespondedStatus(String userName) will check if the respondent has
	 *                               responded a survey and displays the response
	 * 
	 * @param userName
	 */
	public void surveyRespondedStatus(String userName) {

		log.info("\nRespondent exists\n" + LINE);

		boolean checkSurvey = respondentService.checkRespondentPresent(userName);

		int increment = 0;
		for (RespondentBean respondentBeanThree : loginOfRespondent) {
			if (respondentBeanThree.getUserName().contentEquals(userName)) {

				for (SurveyBean surveyLists : SurveyorController.surveyList) {

					if (surveyLists.getdistributedTo().contentEquals(userName)) {

						if (checkSurvey) {
							increment++;
						}

						boolean checkResponse = respondentService.checkResponseStatus(userName);

						if (checkResponse) {
							log.info("You have already responded the survey.You can respond a survey only once\n"
									+ LINE);
							Iterator<String> order = listOfResponse.iterator();
							while (order.hasNext()) {
								log.info(order.next());
							}
							log.info(SEMILINE);

							log.info(LINE + "\n" + SELECTION);
							backToLogin();
						} else {
							respondAssignedSurvey(userName, surveyLists);
						}

					}
				}

			}
		}
		if (increment == 0) {
			log.info("U cannot respond, You are not assigned with any survey to respond\n" + LINE);
			log.info(SELECTION);
			log.info(LINE);
			backToLogin();
		}
	}

	/**
	 * respondAssignedSurvey() responds the assigned survey to the respondent.
	 * 
	 * @param userName,surveyLists
	 */
	public void respondAssignedSurvey(String userName, SurveyBean surveyLists) {

		log.info("WELCOME - " + userName + " - ");

		log.info("You are assigned with the survey : " + surveyLists.getName() + "\n");

		log.info("The survery '" + surveyLists.getName() + "' is a '" + surveyLists.getDescription()
				+ "'.\n\nPlease respond the survey :");

		String a = "1";
		respondentService.setResponse(surveyLists, a);

		QuestionOneBean questionOne = Factory.getQuestionOneBeanInstance();

		String surveyName = ("YOUR SURVEY RESPONSE :\n\nSurvey Name :" + surveyLists.getName()
				+ "\nSurvey Description :" + surveyLists.getDescription() + "\n");
		log.info(LINE + "\nQuestion 01 :\n" + surveyLists.getDefaultQuestionOne() + " :");

		log.info(SEMILINE + "\nSelect your choice :\n(ex:Press '1' if you want to select '"
				+ surveyLists.getQuestionOneOptionOne() + "')\n\n1. " + surveyLists.getQuestionOneOptionOne()
				+ "  \n2. " + surveyLists.getQuestionOneOptionTwo());
		log.info("3. " + surveyLists.getQuestionOneOptionThree() + "  \n4. " + surveyLists.getQuestionOneOptionFour());

		String answerOne = scanner.nextLine();
		while (!respondentService.choiceOneToFour(answerOne)) {
			log.info(VALIDCHOICE);
			answerOne = scanner.nextLine();
		}

		int answerOneInteger = Integer.parseInt(answerOne);
		if (answerOneInteger == 1)
			questionOne.setAnswerOne(surveyLists.getQuestionOneOptionOne());
		if (answerOneInteger == 2)
			questionOne.setAnswerOne(surveyLists.getQuestionOneOptionTwo());
		if (answerOneInteger == 3)
			questionOne.setAnswerOne(surveyLists.getQuestionOneOptionThree());
		if (answerOneInteger == 4)
			questionOne.setAnswerOne(surveyLists.getQuestionOneOptionFour());

		String one = (questionOne.getAnswerOne());

		String oneDetails = ("\n1." + surveyLists.getDefaultQuestionOne() + "?\nResponse: " + one + "\n ");

		QuestionTwoBean questionTwo = Factory.getQuestionTwoBeanInstance();

		log.info(LINE + "\nQuestion 02 :\n" + surveyLists.getDefaultQuestionTwo() + " :");

		log.info(SEMILINE + "\nSelect your choice :\n(ex:Press '1' if you want to select '"
				+ surveyLists.getQuestionTwoOptionOne() + "')\n\n1. " + surveyLists.getQuestionTwoOptionOne()
				+ "  \n2. " + surveyLists.getQuestionTwoOptionTwo());
		log.info("3. " + surveyLists.getQuestionTwoOptionThree() + "   \n4. " + surveyLists.getQuestionTwoOptionFour());

		String answerTwo = scanner.nextLine();

		while (!respondentService.choiceOneToFour(answerTwo)) {
			log.info(VALIDCHOICE);
			answerTwo = scanner.nextLine();
		}

		int answerTwoInteger = Integer.parseInt(answerTwo);

		if (answerTwoInteger == 1)
			questionTwo.setAnswerTwo(surveyLists.getQuestionTwoOptionOne());
		if (answerTwoInteger == 2)
			questionTwo.setAnswerTwo(surveyLists.getQuestionTwoOptionTwo());
		if (answerTwoInteger == 3)
			questionTwo.setAnswerTwo(surveyLists.getQuestionTwoOptionThree());
		if (answerTwoInteger == 4)
			questionTwo.setAnswerTwo(surveyLists.getQuestionTwoOptionFour());

		String two = (questionTwo.getAnswerTwo());
		String twoDetails = ("\n2." + surveyLists.getDefaultQuestionTwo() + "?\nResponse: " + two + "\n");
		log.info(
				"Rules for answering the following Three questions:\n(Your answer should not be blank and should not contain any special characters, numbers)");
		log.info(LINE + "\nQuestion 03 :\n" + surveyLists.getDefaultQuestionThree()
				+ " ?\n[Answer should not exceed 250 Characters]");
		String three = scanner.nextLine();

		while (!respondentService.answerValidationTwoFiftyCharacters(three)) {
			log.info("(Your answer should not be blank and it should not contain any special characters, numbers)");
			three = scanner.nextLine();
		}
		/*
		 * while (!respondentService.answerValidationTwoFiftyCharacters(three)) {
		 * log.info("Your answer should not contain any numbers "); three =
		 * scanner.nextLine(); }
		 */

		String threeDetails = ("\n3." + surveyLists.getDefaultQuestionThree() + "?\nResponse: " + three + "\n");

		log.info(LINE + "\nQuestion04 :\n" + surveyLists.getDefaultQuestionFour()
				+ " ?\n[Answer should not exceed 250 Characters]");
		String four = scanner.nextLine();

		/*
		 * while (!respondentService.surveyLineVerify(four)) { log.
		 * info("(Your answer should not be blank and it should not contain any special characters, numbers"
		 * ); four = scanner.nextLine(); }
		 */
		while (!respondentService.answerValidationTwoFiftyCharacters(four)) {
			log.info(LINE
					+ "\n \"Please Enter Valid Answer.\\n[Your answer should not contain more than 250 Characters.]");
			four = scanner.nextLine();

		}

		String fourDetails = ("\n4." + surveyLists.getDefaultQuestionFour() + "?\nResponse: " + four + "\n");

		log.info(LINE + "\nQuestion 05 :\n" + surveyLists.getDefaultQuestionFive()
				+ " ?\n[Answer should not exceed 4000 Characters]");
		String five = scanner.nextLine();
		/*
		 * while (!respondentService.surveyLineVerify(five)) { log.
		 * info("(Your answer should not be blank and should not contain any special characters, numbers"
		 * ); five = scanner.nextLine(); }
		 */
		while (!respondentService.answerValidationFourThousandCharacters(five)) {
			log.info(LINE + "\n[Answer should not exceed 4000 Characters]\n");
			five = scanner.nextLine();
		}

		String fiveDetails = ("\n5." + surveyLists.getDefaultQuestionFive() + "?\nResponse: " + five + "\n");

		listOfResponse = respondentService.addResponses(surveyName, oneDetails, twoDetails, threeDetails, fourDetails,
				fiveDetails);

		log.info(LINE + "\nThanks for responding the survey \n" + LINE);
		log.info("Select your choice\n(ex: Press '1' to  continue to view your response)\n" + LINE);
		log.info("1 : View your response on this survey");
		log.info("2 : Back\n3 : Exit\n" + LINE);
		String choice = scanner.nextLine();

		while (!respondentService.choiceOneToThree(choice)) {
			log.info("please enter valid choice between [1-3] ");
			choice = scanner.nextLine();
		}
		int viewChoice = Integer.parseInt(choice);
		switch (viewChoice) {
		case 1:
			Iterator<String> order = listOfResponse.iterator();
			while (order.hasNext()) {
				log.info(order.next());
			}
			log.info(SEMILINE);
			log.info(SELECTION + "\n" + LINE);
			backToLogin();
			break;
		case 2:
			log.info(SELECTION + "\n" + LINE);
			backToLogin();
			break;
		case 3:
			log.info("\nThank You !!! Please visit Again\nExit the Screen");
			System.exit(0);
			break;

		default:
			log.info(DUPLICATE);
		}

	}

	/**
	 * This method backToLogin is called when the respondent wants to go back to
	 * previous login steps. He can go back to main page where again he can login in
	 * all the three ways.
	 * 
	 */
	public void backToLogin() {
		String choice = scanner.nextLine();
		while (!respondentService.choiceOneToFour(choice)) {
			log.info(VALIDCHOICE);
			choice = scanner.nextLine();
		}
		int choiceInteger = Integer.parseInt(choice);

		switch (choiceInteger) {
		case 1:
			respondentLogin(new RespondentBean());
			break;
		case 2:
			AdminController adminLogin = Factory.getAdminControllerInstance();
			adminLogin.adminLogin();
			break;
		case 3:
			SurveyorController surveyorLogin = Factory.getSurveyorControllerInstance();
			surveyorLogin.surveyorLoginProcess();
			break;

		case 4:
			log.info("\nThank You !!! Please visit Again\nExit the Screen");
			System.exit(0);
			break;
		default:
			log.info("Enter valid choice");
		}
	}
}
