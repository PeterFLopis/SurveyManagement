package com.capgemini.surveyms.exception;

public class SurveyNotFoundException extends RuntimeException{

	/**
	 * If survey is not present
	 */
	private static final long serialVersionUID = 1L;
	String message = "Survey with this name is  not found";

	public SurveyNotFoundException() {

	}

	public SurveyNotFoundException(String message) {
		super();
		this.message = message;
	}
@Override
	public String getMessage() {
		return message;
	}

}
