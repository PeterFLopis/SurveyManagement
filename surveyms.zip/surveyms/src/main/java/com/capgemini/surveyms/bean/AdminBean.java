
package com.capgemini.surveyms.bean;

import java.io.Serializable;

/**
 * 
 * This is a Bean Class which contains Admin's Login Information Which contains
 * Private variables. The Getter and Setter methods are to Get and Set the
 * Variables.
 */
public class AdminBean implements Serializable {
	/**
	 * 
	 */

	public AdminBean() {
	}

	private static final long serialVersionUID = 1L;
	private String userName;
	private String password;

	/**
	 * This Method Is Used Get Admin's User Name
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * 
	 * This Method Is Used To Set Admin's UserName
	 * 
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 
	 * This Method Is Used To Get Admin's Password
	 * 
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * 
	 * This Method Is Used To set Admin's Password
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "AdminBean [userName=" + userName + ", password=" + password + "]";
	}

}
