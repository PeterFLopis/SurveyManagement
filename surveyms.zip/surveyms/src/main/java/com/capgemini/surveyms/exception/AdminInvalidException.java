package com.capgemini.surveyms.exception;

public class AdminInvalidException extends RuntimeException  {
	/**
	 * If admin is not present.
	 */
	private static final long serialVersionUID = 1L;
	String message = "Admin  not Found";
	
	public AdminInvalidException() {

	}

	public AdminInvalidException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
