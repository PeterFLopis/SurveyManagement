package com.capgemini.surveyms.validations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveyms.factory.Factory;

class InputValidationsTest {

	InputValidations inputValidations = Factory.getInputValidationInstance();

	@Test
	void testOne() {
		assertEquals(true, inputValidations.choiceOneToTwo("2"));
	}

	@Test
	void testTwo() {
		assertEquals(false, inputValidations.choiceOneToTwo("Two"));
	}

	@Test
	void testThree() {
		assertEquals(true, inputValidations.choiceOneToFour("1"));
	}

	@Test
	void testFour() {
		assertEquals(false, inputValidations.choiceOneToFour("one"));
	}

	@Test
	void testFive() {
		assertEquals(true, inputValidations.choiceOneToSix("1"));
	}

	@Test
	void testSix() {
		assertEquals(false, inputValidations.choiceOneToSix("one"));
	}

	@Test
	void testSeven() {
		assertEquals(true, inputValidations.choiceOneToThree("1"));
	}

	@Test
	void testEight() {
		assertEquals(false, inputValidations.choiceOneToThree("one"));
	}

	@Test
	void testNine() {
		assertEquals(true, inputValidations.lineInput("abcd"));
	}

	@Test
	void testTen() {
		assertEquals(false, inputValidations.lineInput(""));
	}

	@Test
	void testEleven() {
		assertEquals(true, inputValidations.nameValidation("peter"));
	}

	@Test
	void testTwelve() {
		assertEquals(false, inputValidations.nameValidation("1"));
	}

	@Test
	void testThirteen() {
		assertEquals(true, inputValidations.passwordValidation("peter"));
	}

	@Test
	void testForteen() {
		assertEquals(false, inputValidations.passwordValidation(" "));
	}

	@Test
	void testFifteen() {
		assertEquals(true, inputValidations.date("2020-12-12"));
	}

	@Test
	void testSixteen() {
		assertEquals(false, inputValidations.date(" "));
	}

	@Test
	void testSeventeen() {
		assertEquals(true, inputValidations.answerValidationForTwoFiftyCharacters("abcd"));
	}

	@Test
	void testEighteen() {
		assertEquals(false, inputValidations.answerValidationForTwoFiftyCharacters(" "));
	}

	@Test
	void testNineteen() {
		assertEquals(true, inputValidations.answerValidationFourThousandCharacters("abcd"));
	}

	@Test
	void testTwenty() {
		assertEquals(false, inputValidations.answerValidationFourThousandCharacters(" "));
	}
	
}
