package com.capgemini.surveyms.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.repository.AdminLoginRepository;
import com.capgemini.surveyms.repository.RespondentLoginRepository;
import com.capgemini.surveyms.repository.SurveyorLoginRepository;

class DaoImplementationTest {

	Dao dao = Factory.getDAOInstance();

	void admindata() {
		AdminLoginRepository adminLoginRepository = Factory.getAdminRepository();
		adminLoginRepository.adminTable();

	}

	@Test
	void testAdminOne() {
		assertEquals(true, dao.adminLogin("admin", "admin"));
	}

	@Test
	void testAdminTwo() {
		assertEquals(false, dao.adminLogin("pinto", "pinto"));
	}

	@Test
	void testThree() {
		assertNotNull(true, dao.adminViewSurveyor());
	}

	@Test
	void addNew() {
		assertEquals(true, dao.addNewRespondent("admin", "admin"));
	}

	@Test
	void testFour() {
		assertNotNull(true, dao.viewRespondentPresent());
	}

	@Test
	void respondentLoginData() {
		RespondentLoginRepository respondentLoginRepository = Factory.getRespondentRepository();
		respondentLoginRepository.respondentTable();
	}

	@Test
	void testRespondentLoginOne() {

		assertEquals(true, dao.checkRespondentPresent("respondent"));
	}

	@Test
	void testRespondentLoginTwo() {

		assertEquals(false, dao.checkRespondentPresent("x1y2z3"));
	}

	void data() {

		SurveyorLoginRepository surveyorRepository = Factory.getSurveyorRepository();
		surveyorRepository.surveyorTable();
	}

	@Test
	void testLogin() {
		assertEquals(true, dao.surveyorLogin("surveyor", "surveyor"));
	}

	@Test
	void testLoginTwo() {
		assertEquals(false, dao.surveyorLogin("a", "a"));
	}

	@Test
	void testDelete() {
		assertEquals(true, dao.deleteSurvey("cricket"));
	}

	@Test
	void testViewSurvey() {
		assertNotNull(true, dao.surveyView());
	}

	@Test
	void testViewSurveyResponses() {
		assertNotNull(true, dao.surveyResponseView());
	}

	private void assertNotNull(boolean actual, boolean surveyView) {

	}

}