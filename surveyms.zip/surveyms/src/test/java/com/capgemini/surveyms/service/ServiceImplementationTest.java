package com.capgemini.surveyms.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveyms.factory.Factory;
import com.capgemini.surveyms.repository.AdminLoginRepository;

class ServiceImplementationTest {

	Service service = Factory.getServiceInstance();

	@Test
	void adminLogindata() {
		AdminLoginRepository adminLoginRepository = Factory.getAdminRepository();
		adminLoginRepository.adminTable();
	}

	@Test
	void testThree() {
		assertEquals(true, service.adminLogin("admin", "admin"));
	}

	@Test
	void testFour() {
		assertEquals(false, service.adminLogin("a", "a"));
	}

	@Test
	void testFive() {
		assertNotNull(true, service.adminViewSurveyor());
	}

	@Test
	void testSix() {
		assertNotNull(true, service.viewRespondentPresent());
	}

	private void assertNotNull(boolean b, boolean adminViewSurveyor) {

	}

	@Test
	void testpasswordVerifyOne() {
		assertEquals(true, service.passwordVerification("peter"));
	}

	@Test
	void testpasswordVerifyTwo() {
		assertEquals(false, service.passwordVerification("peter 123"));
	}

	@Test
	void testcheckRespondentverifyOne() {
		assertEquals(true, service.checkRespondentPresent("respondent"));
	}

	@Test
	void testcheckRespondentverifyTwo() {
		assertEquals(false, service.checkRespondentPresent("123"));
	}

	@Test
	void testcheckRespondentNotpresentOne() {
		assertEquals(true, service.choiceOneToThree("1"));
	}

	@Test
	void testcheckRespondentNotpresentTwo() {
		assertEquals(false, service.choiceOneToThree("11"));
	}

	@Test
	void testanswerTwoFiftyVerifyOne() {
		assertEquals(true, service.answerValidationTwoFiftyCharacters("a a a"));

	}


	@Test
	void testChoiceVerify() {
		assertEquals(true, service.choiceOneToFour("1"));
	}

	@Test
	void testDescriptionVerify() {
		assertEquals(true, service.surveyLineVerify("name"));
	}

	@Test
	void testSurveyorChoiceVerify() {
		assertEquals(true, service.choiceOneToSix("1"));
	}
	
	
	
	
	
	
	

	@Test
	void dateVerify() {
		assertEquals(true, service.dateVerify("2020-11-11"));
	}
	@Test
	void dateVerifyTwo() {
		assertEquals(false, service.dateVerify("11-11-11"));
	}
	
	@Test
	void validatePasswordOne() {
		assertEquals(true, service.validatePassword("jesus"));
	}
	@Test
	void validatePassword() {
		assertEquals(false, service.validatePassword("11-11-11"));
	}
	
	

	@Test
	void choiceOneToSix() {
		assertEquals(true, service.choiceOneToSix("1"));
	}
	
	
	@Test
	void choiceOneToSixTwo() {
		assertEquals(false, service.choiceOneToSix("8"));
	}@Test
	void choiceOneToThreeTwo() {
		assertEquals(false, service.choiceOneToThree("9"));
	}
	@Test
	void respondentService() {
		
		assertEquals(true, service.respondentService("1"));
	}

	@Test
	void respondentServiceTwo() {
		assertEquals(false, service.respondentService("9"));
	}

	@Test
	void nameValidationsOne() {
		assertEquals(true, service.nameValidations("a"));
	}

	@Test
	void nameValidationsTwo() {
		assertEquals(false, service.nameValidations("1"));
	}
	

	@Test
	void answerValidationTwoFiftyCharacters() {
		assertEquals(true, service.answerValidationTwoFiftyCharacters("a"));
	}

	@Test
	void answerValidationTwoFiftyCharactersTwo() {
		assertEquals(false, service.answerValidationTwoFiftyCharacters(" "));
	}

	@Test
	void answerValidationFourThousandCharacters() {
		assertEquals(true, service.answerValidationFourThousandCharacters("a"));
	}

	@Test
	void answerValidationFourThousandCharactersTwo() {
		assertEquals(false, service.answerValidationFourThousandCharacters(" "));
	}

	@SuppressWarnings("unused")
	private void assertNotNull(boolean actual) {

	}

}
